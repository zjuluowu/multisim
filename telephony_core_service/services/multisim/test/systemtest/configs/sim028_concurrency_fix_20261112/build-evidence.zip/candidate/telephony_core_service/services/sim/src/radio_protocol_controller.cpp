/*
 * Copyright (C) 2021-2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include "radio_protocol_controller.h"

#include "radio_event.h"
#include "telephony_log_wrapper.h"

namespace OHOS {
namespace Telephony {
constexpr static const int32_t WAIT_TIME_LONG_SECOND = 60;
static const int64_t COMMUNICATION_TIMEOUT = 45 * 1000; // Set the timeout millisecond for radio protocol communication
static const int64_t SET_ACTIVE_OUT_TIME = 10 * 1000;
ffrt::mutex RadioProtocolController::ctx_;
ffrt::condition_variable RadioProtocolController::cv_;

RadioProtocolController::RadioProtocolController(std::weak_ptr<Telephony::ITelRilManager> telRilManager)
    : TelEventHandler("RadioProtocolController"), telRilManager_(telRilManager)
{}

void RadioProtocolController::Init()
{
    if(Lifecycle()->GetState()!=TelLifecycle::State::Running)return;
    auto telRilManager = telRilManager_.lock();
    if (telRilManager == nullptr) {
        TELEPHONY_LOGE("telRilManager is nullptr");
        return;
    }

    slotCount_ = SIM_SLOT_COUNT_REAL >= DUAL_SLOT_COUNT ? DUAL_SLOT_COUNT : SIM_SLOT_COUNT_REAL;
    InitMemberFunc();
    // make sure communication is in the initial state
    std::unique_lock<ffrt::mutex> radioProtocolLock(radioProtocolMutex_);
    CleanUpCommunication();
    for (int32_t i = 0; i < slotCount_; i++) {
        RadioProtocol protocol;
        protocol.slotId = i;
        protocol.sessionId = 0;
        protocol.phase = RadioProtocolPhase::RADIO_PROTOCOL_PHASE_INITIAL;
        protocol.technology = 0xFFFFFFFF;
        protocol.modemId = 0;
        protocol.status = RadioProtocolStatus::RADIO_PROTOCOL_STATUS_NONE;
        radioProtocol_.emplace_back(protocol);
        telRilManager->RegisterCoreNotify(i, shared_from_this(), RADIO_SIM_RADIO_PROTOCOL_NOTIFY, nullptr);
    }
}

int32_t RadioProtocolController::GetRadioProtocolTech(int32_t slotId)
{
    std::unique_lock<ffrt::mutex> radioProtocolLock(radioProtocolMutex_);
    if (slotId < DEFAULT_SIM_SLOT_ID || slotId >= static_cast<int32_t>(radioProtocol_.size()) || slotId == SIM_SLOT_2) {
        return 0;
    }
    return static_cast<int32_t>(radioProtocol_[slotId].technology);
}

int32_t RadioProtocolController::GetRadioProtocolModemId(int32_t slotId)
{
    std::unique_lock<ffrt::mutex> radioProtocolLock(radioProtocolMutex_);
    if (slotId < DEFAULT_SIM_SLOT_ID || slotId >= static_cast<int32_t>(radioProtocol_.size()) || slotId == SIM_SLOT_2) {
        return 0;
    }
    return static_cast<int32_t>(radioProtocol_[slotId].modemId);
}

int32_t RadioProtocolController::GetRadioProtocolSlotIdByModemId(int32_t modemId)
{
    std::unique_lock<ffrt::mutex> radioProtocolLock(radioProtocolMutex_);
    for (int32_t i = 0; i < static_cast<int32_t>(radioProtocol_.size()); i++) {
        if (radioProtocol_[i].modemId == modemId) {
            return i;
        }
    }
    return -1;
}

void RadioProtocolController::GetRadioProtocol(int32_t slotId)
{
    auto telRilManager = telRilManager_.lock();
    if (telRilManager == nullptr) {
        TELEPHONY_LOGE("telRilManager is nullptr");
        return;
    }
    AppExecFwk::InnerEvent::Pointer event = AppExecFwk::InnerEvent::Get(RADIO_SIM_GET_RADIO_PROTOCOL);
    if (event == nullptr) {
        TELEPHONY_LOGE("event is nullptr");
        return;
    }
    event->SetOwner(shared_from_this());
    telRilManager->GetRadioProtocol(slotId, event);
}

bool RadioProtocolController::SetRadioProtocol(int32_t slotId)
{
    std::unique_lock<ffrt::mutex> radioProtocolLock(radioProtocolMutex_);
    if (isCommunicating_) {
        TELEPHONY_LOGE("protocol is communicating, can not set now");
        return false;
    }

    communicationResponseResult_ = false;
    CleanUpCommunication();
    ExecuteCheckCommunication();
    while (isCommunicating_) {
        TELEPHONY_LOGI("wait for the communication to finish");
        if (radioProtocolCv_.wait_for(radioProtocolLock, std::chrono::seconds(WAIT_TIME_LONG_SECOND)) ==
            ffrt::cv_status::timeout) {
            break;
        }
    }
    return communicationResponseResult_;
}

void RadioProtocolController::InitMemberFunc()
{
    memberFuncMap_[MSG_SIM_TIME_OUT_ACTIVE] =
        [this](const AppExecFwk::InnerEvent::Pointer &event) { ProcessActiveSimTimeOutDone(event); };
    memberFuncMap_[MSG_SIM_SET_ACTIVE] =
        [this](const AppExecFwk::InnerEvent::Pointer &event) { ProcessActiveSimToRilResponse(event); };
    memberFuncMap_[RADIO_SIM_GET_RADIO_PROTOCOL] =
        [this](const AppExecFwk::InnerEvent::Pointer &event) { ProcessGetRadioProtocol(event); };
    memberFuncMap_[RADIO_SIM_CHECK_RADIO_PROTOCOL] =
        [this](const AppExecFwk::InnerEvent::Pointer &event) { ProcessCheckRadioProtocol(event); };
    memberFuncMap_[RADIO_SIM_UPDATE_RADIO_PROTOCOL] =
        [this](const AppExecFwk::InnerEvent::Pointer &event) { ProcessUpdateRadioProtocol(event); };
    memberFuncMap_[RADIO_SIM_RADIO_PROTOCOL_NOTIFY] =
        [this](const AppExecFwk::InnerEvent::Pointer &event) { ProcessRadioProtocolNotify(event); };
    memberFuncMap_[RADIO_SIM_SET_RADIO_PROTOCOL_COMPLETE] =
        [this](const AppExecFwk::InnerEvent::Pointer &event) { ProcessSetRadioProtocolComplete(event); };
    memberFuncMap_[RADIO_SIM_SET_RADIO_PROTOCOL_TIMEOUT] =
        [this](const AppExecFwk::InnerEvent::Pointer &event) { ProcessSetRadioProtocolTimeout(event); };
}

void RadioProtocolController::ProcessEvent(const AppExecFwk::InnerEvent::Pointer &event)
{
    if (event == nullptr) {
        TELEPHONY_LOGE("event is nullptr");
        return;
    }
    auto id = event->GetInnerEventId();
    TELEPHONY_LOGD("id = %{public}d", id);
    auto itFunc = memberFuncMap_.find(id);
    if (itFunc != memberFuncMap_.end()) {
        auto memberFunc = itFunc->second;
        if (memberFunc == nullptr) {
            TELEPHONY_LOGE("memberFunc is nullptr");
            return;
        }
        // Protocol predicates, sessions, phase counters and cleanup share the
        // caller's wait mutex. Active-SIM events use their separate ctx_/cv_.
        const bool protocolEvent = id == RADIO_SIM_GET_RADIO_PROTOCOL ||
            id == RADIO_SIM_CHECK_RADIO_PROTOCOL || id == RADIO_SIM_UPDATE_RADIO_PROTOCOL ||
            id == RADIO_SIM_RADIO_PROTOCOL_NOTIFY || id == RADIO_SIM_SET_RADIO_PROTOCOL_COMPLETE ||
            id == RADIO_SIM_SET_RADIO_PROTOCOL_TIMEOUT;
        std::unique_lock<ffrt::mutex> protocolLock(radioProtocolMutex_, std::defer_lock);
        if (protocolEvent) {
            protocolLock.lock();
        }
        memberFunc(event);
    }
}

void RadioProtocolController::ProcessGetRadioProtocol(const AppExecFwk::InnerEvent::Pointer &event)
{
    if (event == nullptr) {
        TELEPHONY_LOGE("event is nullptr");
        return;
    }
    std::shared_ptr<RadioProtocol> radioProtocol = event->GetSharedObject<RadioProtocol>();
    if (radioProtocol == nullptr) {
        TELEPHONY_LOGE("radioProtocol is nullptr");
        return;
    }
    UpdateRadioProtocol(radioProtocol);
}

void RadioProtocolController::ProcessCheckRadioProtocol(const AppExecFwk::InnerEvent::Pointer &event)
{
    if (!ProcessResponseInfoOfEvent(event)) {
        TELEPHONY_LOGE("failed due to invalid sessionId");
        return;
    }

    if (--communicatingSlotCount_ != 0) {
        TELEPHONY_LOGI("wait for all sim to complete check");
        return;
    }

    if (communicationFailed_) {
        ExecuteCompleteCommunication();
    } else {
        ExecuteUpdateCommunication();
    }
}

void RadioProtocolController::ProcessUpdateRadioProtocol(const AppExecFwk::InnerEvent::Pointer &event)
{
    if (!ProcessResponseInfoOfEvent(event)) {
        TELEPHONY_LOGE("failed due to invalid sessionId");
        return;
    }
}

void RadioProtocolController::ProcessRadioProtocolNotify(const AppExecFwk::InnerEvent::Pointer &event)
{
    if (event == nullptr) {
        TELEPHONY_LOGE("event is nullptr");
        return;
    }
    std::shared_ptr<RadioProtocol> radioProtocol = event->GetSharedObject<RadioProtocol>();
    if (radioProtocol == nullptr || radioProtocol->sessionId != sessionId_) {
        TELEPHONY_LOGE("failed due to invalid sessionId");
        return;
    }

    if (radioProtocol->status == RadioProtocolStatus::RADIO_PROTOCOL_STATUS_FAIL) {
        TELEPHONY_LOGE("update failed");
        communicationFailed_ = true;
    } else {
        UpdateRadioProtocol(radioProtocol);
    }
    if (--communicatingSlotCount_ != 0) {
        TELEPHONY_LOGI("wait for all sim to complete update");
        return;
    }

    ExecuteCompleteCommunication();
}

void RadioProtocolController::ProcessSetRadioProtocolComplete(const AppExecFwk::InnerEvent::Pointer &event)
{
    if (event == nullptr) {
        TELEPHONY_LOGE("event is nullptr");
        return;
    }
    if (!ProcessResponseInfoOfEvent(event)) {
        TELEPHONY_LOGE("failed due to invalid sessionId");
        return;
    }

    if (--communicatingSlotCount_ != 0) {
        TELEPHONY_LOGI("wait for all sim to complete");
        return;
    }

    ProcessCommunicationResponse(!communicationFailed_);
    CleanUpCommunication();
}

void RadioProtocolController::ProcessSetRadioProtocolTimeout(const AppExecFwk::InnerEvent::Pointer &event)
{
    TELEPHONY_LOGI("ProcessSetRadioProtocolTimeout");
    if (event == nullptr) {
        TELEPHONY_LOGE("event is nullptr");
        return;
    }
    auto sessionId = event->GetParam();
    if (sessionId != sessionId_) {
        TELEPHONY_LOGE("failed due to invalid sessionId");
        return;
    }
    ProcessCommunicationResponse(false);
    CleanUpCommunication();
    sessionId_++;
    communicatingSlotCount_ = 0;
    communicationFailed_ = true;
    ExecuteCompleteCommunication();
}

void RadioProtocolController::ExecuteCheckCommunication()
{
    TELEPHONY_LOGI("ExecuteCheckCommunication");
    sessionId_++;
    isCommunicating_ = true;
    SendEvent(RADIO_SIM_SET_RADIO_PROTOCOL_TIMEOUT, sessionId_, COMMUNICATION_TIMEOUT);
    BuildRadioProtocolForCommunication(RadioProtocolPhase::RADIO_PROTOCOL_PHASE_CHECK,
        RadioProtocolStatus::RADIO_PROTOCOL_STATUS_NONE);
    ResetNextCommunicationSlotCount();
    SendRadioProtocolEvent(oldRadioProtocol_, RADIO_SIM_CHECK_RADIO_PROTOCOL);
}

// Called with radioProtocolMutex_ held by protocol dispatch or SetRadioProtocol.
void RadioProtocolController::ExecuteUpdateCommunication()
{
    BuildRadioProtocolForCommunication(RadioProtocolPhase::RADIO_PROTOCOL_PHASE_UPDATE,
        RadioProtocolStatus::RADIO_PROTOCOL_STATUS_NONE);
    ResetNextCommunicationSlotCount();
    SendRadioProtocolEvent(newRadioProtocol_, RADIO_SIM_UPDATE_RADIO_PROTOCOL);
}

// Called with radioProtocolMutex_ held by protocol dispatch or SetRadioProtocol.
void RadioProtocolController::ExecuteCompleteCommunication()
{
    TELEPHONY_LOGI("failed:%{public}d", communicationFailed_);
    BuildRadioProtocolForCommunication(RadioProtocolPhase::RADIO_PROTOCOL_PHASE_COMPLETE,
        communicationFailed_ ? RadioProtocolStatus::RADIO_PROTOCOL_STATUS_FAIL :
        RadioProtocolStatus::RADIO_PROTOCOL_STATUS_SUCCESS);
    ResetNextCommunicationSlotCount();
    SendRadioProtocolEvent(communicationFailed_ ? oldRadioProtocol_ : newRadioProtocol_,
        RADIO_SIM_SET_RADIO_PROTOCOL_COMPLETE);
}

void RadioProtocolController::ResetNextCommunicationSlotCount()
{
    communicatingSlotCount_ = slotCount_;
}

void RadioProtocolController::BuildRadioProtocolForCommunication(RadioProtocolPhase phase, RadioProtocolStatus status)
{
    switch (phase) {
        case RadioProtocolPhase::RADIO_PROTOCOL_PHASE_CHECK: {
            if (slotCount_ > static_cast<int32_t>(radioProtocol_.size()) || slotCount_ < 0) {
                TELEPHONY_LOGE("error, size = %{public}zu, slotCount_ = %{public}d", radioProtocol_.size(), slotCount_);
                break;
            }
            for (int32_t i = 0; i < slotCount_; i++) {
                RadioProtocol radioProtocol;
                radioProtocol.slotId = i;
                radioProtocol.sessionId = sessionId_;
                radioProtocol.phase = phase;
                radioProtocol.technology = radioProtocol_[i].technology;
                radioProtocol.modemId = radioProtocol_[i].modemId;
                radioProtocol.status = status;
                oldRadioProtocol_.emplace_back(radioProtocol);
                newRadioProtocol_.emplace_back(radioProtocol);
            }
            // Switch the tech and modemId of main and non-main card
            for (int32_t i = 0; i < slotCount_; i++) {
                newRadioProtocol_[i].technology = radioProtocol_[slotCount_ - 1 - i].technology;
                newRadioProtocol_[i].modemId = radioProtocol_[slotCount_ - 1 - i].modemId;
            }
            break;
        }
        case RadioProtocolPhase::RADIO_PROTOCOL_PHASE_UPDATE:
        case RadioProtocolPhase::RADIO_PROTOCOL_PHASE_NOTIFY:
        case RadioProtocolPhase::RADIO_PROTOCOL_PHASE_COMPLETE: {
            if (slotCount_ < 0 || static_cast<int32_t>(oldRadioProtocol_.size()) < slotCount_ ||
                static_cast<int32_t>(newRadioProtocol_.size()) < slotCount_) {
                TELEPHONY_LOGE("error, old size = %{public}zu, new size = %{public}zu, slotCount_ = %{public}d",
                    oldRadioProtocol_.size(), newRadioProtocol_.size(), slotCount_);
                break;
            }
            for (int32_t i = 0; i < slotCount_; i++) {
                oldRadioProtocol_[i].sessionId = sessionId_;
                oldRadioProtocol_[i].phase = phase;
                oldRadioProtocol_[i].status = status;
                newRadioProtocol_[i].sessionId = sessionId_;
                newRadioProtocol_[i].phase = phase;
                newRadioProtocol_[i].status = status;
            }
            break;
        }
        default:
            TELEPHONY_LOGE("BuildRadioProtocolForCommunication invalid phase");
            break;
    }
}

void RadioProtocolController::SendRadioProtocolEvent(std::vector<RadioProtocol> radioProtocol, uint32_t eventId)
{
    auto telRilManager = telRilManager_.lock();
    if (telRilManager == nullptr || radioProtocol.empty()) {
        TELEPHONY_LOGE("SendRadioProtocol telRilManager or radioProtocol is nullptr");
        ProcessCommunicationResponse(false);
        CleanUpCommunication();
        return;
    }
    if (slotCount_ > static_cast<int32_t>(radioProtocol.size()) || slotCount_ < 0) {
        TELEPHONY_LOGE("error, size = %{public}zu, slotCount_ = %{public}d", radioProtocol_.size(), slotCount_);
        ProcessCommunicationResponse(false);
        CleanUpCommunication();
        return;
    }
    for (int32_t i = 0; i < slotCount_; i++) {
        if (i == SIM_SLOT_2) {
            continue;
        }
        AppExecFwk::InnerEvent::Pointer event = AppExecFwk::InnerEvent::Get(eventId);
        if (event == nullptr) {
            TELEPHONY_LOGE("SendRadioProtocol event is nullptr");
            ProcessCommunicationResponse(false);
            CleanUpCommunication();
            return;
        }
        event->SetOwner(shared_from_this());
        telRilManager->SetRadioProtocol(i, radioProtocol[i], event);
    }
}

// Called with radioProtocolMutex_ held by protocol dispatch or SetRadioProtocol.
void RadioProtocolController::UpdateRadioProtocol(std::shared_ptr<RadioProtocol> radioProtocol)
{
    int32_t slotId = radioProtocol->slotId;
    if ((slotId >= DEFAULT_SIM_SLOT_ID) && (slotId < static_cast<int32_t>(radioProtocol_.size()))) {
        radioProtocol_[slotId].sessionId = radioProtocol->sessionId;
        radioProtocol_[slotId].phase = radioProtocol->phase;
        radioProtocol_[slotId].technology = radioProtocol->technology;
        radioProtocol_[slotId].modemId = radioProtocol->modemId;
        radioProtocol_[slotId].status = radioProtocol->status;
    }
}

bool RadioProtocolController::ProcessResponseInfoOfEvent(const AppExecFwk::InnerEvent::Pointer &event)
{
    if (event == nullptr) {
        TELEPHONY_LOGE("event is nullptr");
        return false;
    }
    std::shared_ptr<RadioResponseInfo> responseInfo = event->GetSharedObject<RadioResponseInfo>();
    if (responseInfo != nullptr && responseInfo->error != ErrType::NONE) {
        TELEPHONY_LOGE("error:%{public}d", responseInfo->error);
        communicationFailed_ = true;
        return true;
    }

    std::shared_ptr<RadioProtocol> radioProtocol = event->GetSharedObject<RadioProtocol>();
    return radioProtocol != nullptr && radioProtocol->sessionId == sessionId_;
}

void RadioProtocolController::CleanUpCommunication()
{
    TELEPHONY_LOGI("CleanUpCommunication");
    RemoveEvent(RADIO_SIM_SET_RADIO_PROTOCOL_TIMEOUT);
    communicationFailed_ = false;
    std::vector<RadioProtocol>().swap(oldRadioProtocol_);
    std::vector<RadioProtocol>().swap(newRadioProtocol_);
}

void RadioProtocolController::ProcessCommunicationResponse(bool result)
{
    communicationResponseResult_ = result;
    isCommunicating_ = false;
    radioProtocolCv_.notify_all();
}

void RadioProtocolController::UnRegisterEvents()
{
    auto telRilManager = telRilManager_.lock();
    if (telRilManager == nullptr) {
        TELEPHONY_LOGE("UnRegisterEvents telRilManager is nullptr");
        return;
    }
    for (int32_t i = 0; i < slotCount_; i++) {
        telRilManager->UnRegisterCoreNotify(i, shared_from_this(), RADIO_SIM_RADIO_PROTOCOL_NOTIFY);
    }
}

void RadioProtocolController::RadioProtocolControllerWait()
{
    responseReady_ = false;
}

void RadioProtocolController::RadioProtocolControllerContinue()
{
    std::unique_lock<ffrt::mutex> lck(ctx_);
    responseReady_ = true;
    cv_.notify_all();
}

bool RadioProtocolController::RadioProtocolControllerPoll()
{
    return responseReady_;
}

void RadioProtocolController::ProcessActiveSimTimeOutDone(const AppExecFwk::InnerEvent::Pointer &event)
{
    TELEPHONY_LOGI("ProcessActiveSimTimeOutDone");
    RadioProtocolControllerContinue();
}

bool RadioProtocolController::SetActiveSimToRil(int32_t slotId, int32_t type, int32_t enable)
{
    TELEPHONY_LOGI("SetActiveSim(), slotId=%{public}d, enable=%{public}d", slotId, enable);
    auto telRilManager = telRilManager_.lock();
    if (telRilManager == nullptr) {
        TELEPHONY_LOGE("SetActiveSim nullptr");
        return false;
    }
    auto event = AppExecFwk::InnerEvent::Get(MSG_SIM_SET_ACTIVE);
    if (event == nullptr) {
        TELEPHONY_LOGE("event is nullptr!");
        return false;
    }
    activeResponse_ = 1;
    event->SetOwner(shared_from_this());
    RemoveEvent(MSG_SIM_TIME_OUT_ACTIVE);
    SendEvent(MSG_SIM_TIME_OUT_ACTIVE, SET_ACTIVE_OUT_TIME, Priority::LOW);
    telRilManager->SetActiveSim(slotId, type, enable, event);
    return true;
}

void RadioProtocolController::ProcessActiveSimToRilResponse(const AppExecFwk::InnerEvent::Pointer &event)
{
    if (event == nullptr) {
        TELEPHONY_LOGE("event is nullptr");
        return;
    }
    TELEPHONY_LOGI("ProcessActiveSimToRilResponse");
    int32_t result = 0;
    std::shared_ptr<ErrType> param = event->GetSharedObject<ErrType>();
    std::shared_ptr<RadioResponseInfo> response = event->GetSharedObject<RadioResponseInfo>();
    if ((param == nullptr) && (response == nullptr)) {
        TELEPHONY_LOGE("Get response fail");
        RadioProtocolControllerContinue();
        return;
    }
    if (param != nullptr) {
        result = static_cast<int32_t>(*param);
    } else {
        result = static_cast<int32_t>(response->error);
    }
    TELEPHONY_LOGI("activeResponse = %{public}d", result);
    activeResponse_ = result;
    RadioProtocolControllerContinue();
}

int32_t RadioProtocolController::GetActiveSimToRilResult()
{
    TELEPHONY_LOGI("Get active sim result");
    RemoveEvent(MSG_SIM_TIME_OUT_ACTIVE);
    return activeResponse_;
}
} // namespace Telephony
} // namespace OHOS
