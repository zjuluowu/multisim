#pragma once
// Logging-only sink; discard all format arguments to avoid identity leakage.
enum { LOG_CORE, LOG_DEBUG, LOG_INFO, LOG_WARN, LOG_ERROR, LOG_FATAL };
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <thread>
#include <chrono>
inline int HILOG_IMPL(int, int, unsigned int, const char*, const char* fmt, ...) {
    if (!std::getenv("SIM_HOST_TRACE")) return 0;
    std::string clean(fmt);
    for (const auto &tag : {std::string("{public}"), std::string("{private}")})
        for (size_t p; (p=clean.find(tag))!=std::string::npos;) clean.erase(p,tag.size());
    va_list args; va_start(args,fmt);
    flockfile(stderr);
    std::fprintf(stderr,"HOST_TRACE us=%lld tid=%zu ",
        static_cast<long long>(std::chrono::duration_cast<std::chrono::microseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count()),std::hash<std::thread::id>{}(std::this_thread::get_id()));
    std::vfprintf(stderr,clean.c_str(),args); std::fputc('\n',stderr);
    funlockfile(stderr); va_end(args); return 0;
}

// Fork diagnostic call shape; deliberately discards all arguments like HILOG_IMPL.
inline void HILOG_COMM_INFO(const char *, ...) {}
inline void HILOG_COMM_ERROR(const char *, ...) {}
