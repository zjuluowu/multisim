from pathlib import Path
import json,re
w=Path(json.load(open('/tmp/sim028-concurrency-current.json'))['work']);repo=w/'ci/repo';rel='telephony_core_service/services/sim/';h=repo/(rel+'include/sim_state_handle.h');c=repo/(rel+'src/sim_state_handle.cpp');s=h.read_text();s=s.replace('    SimState externalState_; // need to broadcast sim state;','    // State snapshots cross StateHandle, Monitor and File queues. Never hold\n    // this mutex across notification, RIL or platform callbacks.\n    ffrt::mutex externalStateMutex_;\n    SimState externalState_ = SimState::SIM_STATE_UNKNOWN;');h.write_text(s)
s=c.read_text();s=re.sub(r'externalState_ = ([^;]+);',r'SetSimState(\1);',s);s=s.replace('externalState_', 'GetSimState()');s=s.replace('SimState SimStateHandle::GetSimState()\n{\n    return GetSimState();\n}','SimState SimStateHandle::GetSimState()\n{\n    std::lock_guard<ffrt::mutex> lock(externalStateMutex_);\n    return externalState_;\n}');s=s.replace('void SimStateHandle::SetSimState(SimState simState)\n{\n    SetSimState(simState);\n}','void SimStateHandle::SetSimState(SimState simState)\n{\n    std::lock_guard<ffrt::mutex> lock(externalStateMutex_);\n    externalState_ = simState;\n}');assert s.count('externalState_')==2;c.write_text(s)
# Optional Host log sink. It observes existing production log calls only.
p=repo/'telephony_core_service/services/multisim/test/systemtest/stubs/include/hilog/log.h';s=p.read_text();s=s.replace('inline int HILOG_IMPL(int, int, unsigned int, const char*, const char*, ...) { return 0; }','''#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <thread>
#include <chrono>
inline int HILOG_IMPL(int, int, unsigned int, const char*, const char* fmt, ...) {
    if (!std::getenv("SIM_HOST_TRACE")) return 0;
    std::string clean(fmt);
    for (const auto &tag : {std::string("{public}"), std::string("{private}")})
        for (size_t p; (p=clean.find(tag))!=std::string::npos;) clean.erase(p,tag.size());
    va_list args; va_start(args,fmt);
    flockfile(stderr);
    std::fprintf(stderr,"HOST_TRACE us=%lld tid=%zu ",
        static_cast<long long>(std::chrono::duration_cast<std::chrono::microseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count()),std::hash<std::thread::id>{}(std::this_thread::get_id()));
    std::vfprintf(stderr,clean.c_str(),args); std::fputc('\\n',stderr);
    funlockfile(stderr); va_end(args); return 0;
}''');p.write_text(s)
print('state lock candidate implemented in isolated source')
