#include <gmock/gmock.h>
#include "sim_manager.h"
#include "core_service_sim.h"
#include "parameter_mock.h"
#include "security_boundary.h"
#include "external_services_mock.h"
#include "ffrt_runtime.h"
#include "real_scenario.h"
#include <future>
#include <optional>
#include "sim_state_handle.h"
namespace {
using namespace OHOS::Telephony;
using namespace std::chrono_literals;
TEST(RealSimPrimary, InitializesRealManagerAndControllerWithoutRil)
{
    testing::StrictMock<SimHost::MockParameterService> parameters;
    EXPECT_CALL(parameters, Read(testing::_, testing::_, testing::_, testing::_))
        .WillRepeatedly([](const char *key, const char *fallback, char *out, unsigned size) {
            return SimHost::CopyParameterValue(std::string(key) == "const.telephony.slotCount" ? "2" : fallback, out, size);
        });
    SimHost::ScopedParameterService installed(parameters);
    testing::StrictMock<PrimarySlotHost::ExternalIdentity> identity;
    PrimarySlotHost::IdentityScope security(identity);
    testing::StrictMock<SimHost::MockExternalServices> services;
    EXPECT_CALL(services, Publish(testing::_, testing::_)).WillRepeatedly(testing::Return(true));
    EXPECT_CALL(services, CreateDataShare(testing::_, testing::_, testing::_, testing::_, testing::_))
        .WillRepeatedly(testing::Return(nullptr)); // explicit unavailable Provider; never fabricated success.
    SimHost::ScopedExternalServices external(services);
    auto manager = std::make_shared<SimManager>(nullptr);
    ASSERT_TRUE(manager->OnInit(SIM_SLOT_COUNT_MD + 1));
    EXPECT_EQ(manager->GetMaxSimCount(), 2);
    EXPECT_EQ(manager->SetPrimarySlotId(1, true), TELEPHONY_ERR_NO_SIM_CARD);
    EXPECT_FALSE(manager->IsSetPrimarySlotIdInProgress());
    SimHost::StopCallingThreadTasks();
    EXPECT_TRUE(manager->Stop());
    manager.reset();
    EXPECT_TRUE(SimHost::AwaitSchedulerStopped(3s));
}
TEST(RealSimPrimary, C0CoreToRealManagerAndController)
{
    Sim028Host::RealScenario scenario;
    ASSERT_TRUE(scenario.StartLockedCard());
    bool present = false;
    EXPECT_EQ(scenario.manager->HasSimCard(1, present), TELEPHONY_ERR_SUCCESS);
    ASSERT_TRUE(present);
    ASSERT_TRUE(scenario.manager->IsSimActive(1));
    // C0 is backed by an actual device-query reply, rather than assuming the
    // controller's initial modemId value represents the current mapping.
    EXPECT_CALL(*scenario.ril, GetRadioProtocol(testing::_, testing::_)).Times(2)
        .WillRepeatedly([](int slot, const auto &event) {
            auto reported = std::make_shared<RadioProtocol>();
            reported->slotId = slot; reported->modemId = 1 - slot;
            reported->technology = slot == 1 ? 0x11 : 0x22;
            Sim028Host::RealScenario::Reply({slot, event->GetOwner(), event->GetInnerEventId()}, reported);
            return 0;
        });
    scenario.manager->GetRadioProtocol(0); scenario.manager->GetRadioProtocol(1);
    const auto mappingDeadline = std::chrono::steady_clock::now() + 3s;
    while ((scenario.manager->GetRadioProtocolSlotIdByModemId(0) != 1 ||
        scenario.manager->GetRadioProtocolTech(1) != 0x11 || scenario.manager->GetRadioProtocolTech(0) != 0x22) &&
        std::chrono::steady_clock::now() < mappingDeadline) std::this_thread::sleep_for(1ms);
    ASSERT_EQ(scenario.manager->GetRadioProtocolSlotIdByModemId(0), 1);
    ASSERT_EQ(scenario.manager->GetRadioProtocolTech(1), 0x11);
    ASSERT_EQ(scenario.manager->GetRadioProtocolTech(0), 0x22);
    scenario.ClearObservations();
    scenario.Permit();
    EXPECT_CALL(*scenario.ril, SetPrimarySlot(testing::_, testing::_)).Times(0);
    EXPECT_CALL(*scenario.ril, SetRadioProtocol(testing::_, testing::_, testing::_)).Times(0);
    EXPECT_EQ(scenario.core.SetPrimarySlotId(1), TELEPHONY_ERR_SUCCESS);
    EXPECT_FALSE(scenario.manager->IsSetPrimarySlotIdInProgress());
    std::lock_guard<std::mutex> lock(scenario.mutex);
    EXPECT_EQ(scenario.parametersDb["persist.telephony.MainSlotId"], "1") << "PRIMARY_COMMIT_TARGET";
    EXPECT_EQ(scenario.parametersDb["persist.telephony.MainCellularDataSlotId"], "1");
    EXPECT_EQ(scenario.parametersDb["persist.telephony.MainCard.Iccid"], "AB2FA72FFEABDAB4E56CB9230C9A119AB236ECE269144D4E335A36E2D26558F2");
    scenario.ExpectNotifications(true, 0, false);
    testing::Test::RecordProperty("business_assertions_before_cleanup", testing::Test::HasFailure() ? "FAIL" : "PASS");
}
TEST(RealSimPrimary, BDirectRilSuccessCommitsAfterReply)
{
    Sim028Host::RealScenario s(true);
    ASSERT_TRUE(s.StartLockedCard());
    s.ClearObservations(); s.Permit();
    using Pending = Sim028Host::RealScenario::Pending;
    std::optional<Pending> request;
    EXPECT_CALL(*s.ril, SetPrimarySlot(1, testing::_)).Times(1).WillOnce([&](int slot, const auto &event) {
        EXPECT_TRUE(std::dynamic_pointer_cast<MultiSimController>(event->GetOwner()));
        std::lock_guard<std::mutex> lock(s.mutex);
        request = Pending{slot, event->GetOwner(), event->GetInnerEventId()}; s.changed.notify_all(); return 0;
    });
    EXPECT_CALL(*s.ril, SetRadioProtocol(testing::_, testing::_, testing::_)).Times(0);
    auto caller = std::async(std::launch::async, [&] { return s.core.SetPrimarySlotId(1); });
    {
        std::unique_lock<std::mutex> lock(s.mutex);
        ASSERT_TRUE(s.changed.wait_for(lock, 3s, [&] { return request.has_value(); }));
        EXPECT_NE(s.parametersDb["persist.telephony.MainSlotId"], "1") << "NO_EARLY_COMMIT";
    }
    EXPECT_EQ(caller.wait_for(50ms), std::future_status::timeout);
    EXPECT_TRUE(s.manager->IsSetPrimarySlotIdInProgress());
    auto reply = std::make_shared<RadioResponseInfo>(); reply->error = ErrType::NONE;
    Sim028Host::RealScenario::Reply(*request, reply);
    ASSERT_EQ(caller.wait_for(3s), std::future_status::ready);
    EXPECT_EQ(caller.get(), TELEPHONY_ERR_SUCCESS);
    EXPECT_FALSE(s.manager->IsSetPrimarySlotIdInProgress());
    std::lock_guard<std::mutex> lock(s.mutex);
    EXPECT_EQ(s.parametersDb["persist.telephony.MainSlotId"], "1") << "PRIMARY_COMMIT_TARGET";
    EXPECT_EQ(s.parametersDb["persist.telephony.MainCellularDataSlotId"], "1");
    s.ExpectNotifications(true, 1, true);
    testing::Test::RecordProperty("business_assertions_before_cleanup", testing::Test::HasFailure() ? "FAIL" : "PASS");
}
TEST(RealSimPrimary, BDirectRilFailureKeepsPreviousPrimary)
{
    Sim028Host::RealScenario s(true);
    ASSERT_TRUE(s.StartLockedCard()); s.ClearObservations(); s.Permit();
    { std::lock_guard<std::mutex> lock(s.mutex); s.parametersDb["persist.telephony.MainSlotId"] = "0"; }
    EXPECT_CALL(*s.ril, SetPrimarySlot(1, testing::_)).Times(1).WillOnce([](int slot, const auto &event) {
        auto reply = std::make_shared<RadioResponseInfo>(); reply->error = ErrType::ERR_GENERIC_FAILURE;
        Sim028Host::RealScenario::Reply({slot, event->GetOwner(), event->GetInnerEventId()}, reply); return 0;
    });
    EXPECT_CALL(*s.ril, SetRadioProtocol(testing::_, testing::_, testing::_)).Times(0);
    EXPECT_EQ(s.core.SetPrimarySlotId(1), TELEPHONY_ERR_LOCAL_PTR_NULL);
    EXPECT_FALSE(s.manager->IsSetPrimarySlotIdInProgress());
    std::lock_guard<std::mutex> lock(s.mutex);
    EXPECT_EQ(s.parametersDb["persist.telephony.MainSlotId"], "0") << "FAILURE_PRESERVES_PRIMARY";
    EXPECT_NE(s.parametersDb["persist.telephony.MainCellularDataSlotId"], "1");
    s.ExpectNotifications(false, 1, true);
    testing::Test::RecordProperty("business_assertions_before_cleanup", testing::Test::HasFailure() ? "FAIL" : "PASS");
}
TEST(RealSimPrimary, C1ThreePhasesWithStaleCheckResponseRejected)
{
    using namespace Sim028Host;
    RealScenario s;
    ASSERT_TRUE(s.StartLockedCard()); s.ClearObservations(); s.Permit();
    EXPECT_CALL(*s.ril, SetPrimarySlot(testing::_, testing::_)).Times(0);
    EXPECT_CALL(*s.ril, GetRadioProtocol(testing::_, testing::_)).Times(2).WillRepeatedly([](int slot, const auto &event) {
        auto response = std::make_shared<RadioProtocol>();
        response->slotId = slot; response->modemId = slot; response->technology = slot == 0 ? 0x11 : 0x22;
        RealScenario::Reply({slot, event->GetOwner(), event->GetInnerEventId()}, response); return 0;
    });
    s.manager->GetRadioProtocol(0); s.manager->GetRadioProtocol(1);
    const auto deadline = std::chrono::steady_clock::now() + 3s;
    while (s.manager->GetRadioProtocolSlotIdByModemId(1) != 1 && std::chrono::steady_clock::now() < deadline)
        std::this_thread::sleep_for(1ms);
    ASSERT_EQ(s.manager->GetRadioProtocolSlotIdByModemId(1), 1);
    struct ProtocolRequest { RealScenario::Pending transport; RadioProtocol protocol; };
    std::vector<ProtocolRequest> requests;
    EXPECT_CALL(*s.ril, SetRadioProtocol(testing::_, testing::_, testing::_)).Times(6)
        .WillRepeatedly([&](int slot, RadioProtocol protocol, const auto &event) {
            std::cout << "TRACE radio slot=" << slot << " session=" << protocol.sessionId
                << " phase=" << static_cast<int>(protocol.phase) << " modem=" << protocol.modemId << "\n";
            EXPECT_EQ(protocol.slotId, slot);
            EXPECT_TRUE(std::dynamic_pointer_cast<RadioProtocolController>(event->GetOwner()));
            std::lock_guard<std::mutex> lock(s.mutex);
            requests.push_back({{slot, event->GetOwner(), event->GetInnerEventId()}, protocol});
            s.changed.notify_all(); return 0;
        });
    auto caller = std::async(std::launch::async, [&] { return s.core.SetPrimarySlotId(1); });
    int session = -1;
    for (unsigned stage = 0; stage < 3; ++stage) {
        std::vector<ProtocolRequest> pair;
        {
            std::unique_lock<std::mutex> lock(s.mutex);
            ASSERT_TRUE(s.changed.wait_for(lock, 3s, [&] { return requests.size() >= 2 * (stage + 1); }));
            pair.assign(requests.begin() + stage * 2, requests.begin() + stage * 2 + 2);
        }
        EXPECT_EQ(caller.wait_for(10ms), std::future_status::timeout);
        for (const auto &request : pair) {
            auto reply = std::make_shared<RadioProtocol>(request.protocol);
            if (session == -1) session = reply->sessionId;
            EXPECT_EQ(reply->sessionId, session);
            EXPECT_EQ(static_cast<int>(reply->phase), stage == 0 ? 1 : stage == 1 ? 2 : 4);
            EXPECT_EQ(reply->modemId, stage == 0 ? request.transport.slot : 1 - request.transport.slot);
            EXPECT_EQ(reply->technology, stage == 0 ? (request.transport.slot == 0 ? 0x11 : 0x22) :
                (request.transport.slot == 0 ? 0x22 : 0x11));
            if (stage == 0 && request.transport.slot == 0) {
                auto stale = std::make_shared<RadioProtocol>(*reply); stale->sessionId += 99;
                RealScenario::Reply(request.transport, stale);
                EXPECT_EQ(caller.wait_for(20ms), std::future_status::timeout);
                std::lock_guard<std::mutex> lock(s.mutex); EXPECT_EQ(requests.size(), 2u);
            }
            RealScenario::Reply(request.transport, reply);
            if (stage == 1) {
                reply = std::make_shared<RadioProtocol>(*reply);
                reply->phase = RadioProtocolPhase::RADIO_PROTOCOL_PHASE_NOTIFY;
                reply->status = RadioProtocolStatus::RADIO_PROTOCOL_STATUS_SUCCESS;
                std::weak_ptr<AppExecFwk::EventHandler> owner;
                { std::lock_guard<std::mutex> lock(s.mutex); owner = s.notifications.at({request.transport.slot, RADIO_SIM_RADIO_PROTOCOL_NOTIFY}); }
                RealScenario::Reply({request.transport.slot, owner, RADIO_SIM_RADIO_PROTOCOL_NOTIFY}, reply);
            }
        }
    }
    ASSERT_EQ(caller.wait_for(3s), std::future_status::ready);
    EXPECT_EQ(caller.get(), TELEPHONY_ERR_SUCCESS);
    EXPECT_EQ(s.manager->GetRadioProtocolSlotIdByModemId(0), 1);
    EXPECT_FALSE(s.manager->IsSetPrimarySlotIdInProgress());
    std::lock_guard<std::mutex> lock(s.mutex);
    EXPECT_EQ(s.parametersDb["persist.telephony.MainSlotId"], "1") << "PRIMARY_COMMIT_TARGET";
    EXPECT_EQ(s.parametersDb["persist.telephony.MainCellularDataSlotId"], "1");
    s.ExpectNotifications(true, 1, false);
    testing::Test::RecordProperty("business_assertions_before_cleanup", testing::Test::HasFailure() ? "FAIL" : "PASS");
}
TEST(RealSimPrimary, BRealTimeoutKeepsPreviousPrimary)
{
    Sim028Host::RealScenario s(true);
    ASSERT_TRUE(s.StartLockedCard()); s.ClearObservations(); s.Permit();
    { std::lock_guard<std::mutex> lock(s.mutex); s.parametersDb["persist.telephony.MainSlotId"] = "0"; }
    EXPECT_CALL(*s.ril, SetPrimarySlot(1, testing::_)).Times(1).WillOnce([](int, const auto &) {
        return 0; // device accepted the request but supplies no reply; real 45-second timer must end it
    });
    EXPECT_CALL(*s.ril, SetRadioProtocol(testing::_, testing::_, testing::_)).Times(0);
    const auto start = std::chrono::steady_clock::now();
    EXPECT_EQ(s.core.SetPrimarySlotId(1), TELEPHONY_ERR_LOCAL_PTR_NULL);
    EXPECT_GE(std::chrono::steady_clock::now() - start, 44s);
    EXPECT_FALSE(s.manager->IsSetPrimarySlotIdInProgress());
    std::lock_guard<std::mutex> lock(s.mutex);
    EXPECT_EQ(s.parametersDb["persist.telephony.MainSlotId"], "0") << "TIMEOUT_PRESERVES_PRIMARY";
    EXPECT_NE(s.parametersDb["persist.telephony.MainCellularDataSlotId"], "1");
    s.ExpectNotifications(false, 1, true);
    testing::Test::RecordProperty("business_assertions_before_cleanup", testing::Test::HasFailure() ? "FAIL" : "PASS");
}
void VerifyC1FailureRetries(bool stopDuringRetry = false, bool interleaveHandoff = false)
{
    using namespace Sim028Host;
    // Callback state must outlive RealScenario::Stop even after a fatal assertion.
    std::map<int, std::vector<std::pair<int, RadioProtocolPhase>>> phases;
    unsigned requests = 0;
    struct RetryHandoff {
        std::mutex mutex;std::condition_variable changed;
        bool paused=false,release=false,producerDone=false,insertedWhilePaused=false;
        std::optional<RealScenario::Pending> first,second;
    };
    auto handoff=std::make_shared<RetryHandoff>();
    RealScenario s;
    ASSERT_TRUE(s.StartLockedCard()); s.ClearObservations(); s.Permit();
    { std::lock_guard<std::mutex> lock(s.mutex);
      s.parametersDb["persist.telephony.MainSlotId"] = "0";
      s.parametersDb["persist.telephony.MainCard.Iccid"] = "previous-parameter-value"; }
    EXPECT_CALL(*s.ril, SetPrimarySlot(testing::_, testing::_)).Times(0);
    EXPECT_CALL(*s.ril, GetRadioProtocol(testing::_, testing::_)).Times(2).WillRepeatedly([](int slot, const auto &event) {
        auto response = std::make_shared<RadioProtocol>(); response->slotId = slot;
        response->modemId = slot; response->technology = slot == 0 ? 0x11 : 0x22;
        RealScenario::Reply({slot, event->GetOwner(), event->GetInnerEventId()}, response); return 0;
    });
    s.manager->GetRadioProtocol(0); s.manager->GetRadioProtocol(1);
    const auto deadline = std::chrono::steady_clock::now() + 3s;
    while (s.manager->GetRadioProtocolSlotIdByModemId(1) != 1 && std::chrono::steady_clock::now() < deadline)
        std::this_thread::sleep_for(1ms);
    ASSERT_EQ(s.manager->GetRadioProtocolSlotIdByModemId(1), 1);
    struct ClearObserver {~ClearObserver(){SimHost::SetLogObserver({});}} clearObserver;
    std::future<bool> coordinate;
    if(interleaveHandoff) {
        SimHost::SetLogObserver([handoff](const std::string &line) {
            if(line.find("SIM028_QUEUE_HANDOFF name=RadioProtocolController")==std::string::npos ||
               line.find("delay_us=4")==std::string::npos)return;
            std::unique_lock<std::mutex> lock(handoff->mutex);
            if(!handoff->second || handoff->paused)return;
            handoff->paused=true;handoff->changed.notify_all();
            handoff->changed.wait(lock,[&]{return handoff->release;});
        });
        coordinate=std::async(std::launch::async,[handoff] {
            RealScenario::Pending pending;
            {std::unique_lock<std::mutex> lock(handoff->mutex);
             if(!handoff->changed.wait_for(lock,10s,[&]{return handoff->paused;}))return false;
             pending=*handoff->second;}
            auto producer=std::async(std::launch::async,[handoff,pending] {
                auto error=std::make_shared<RadioResponseInfo>();error->error=ErrType::ERR_GENERIC_FAILURE;
                RealScenario::Reply(pending,error);
                std::lock_guard<std::mutex> lock(handoff->mutex);handoff->producerDone=true;handoff->changed.notify_all();
            });
            {std::unique_lock<std::mutex> lock(handoff->mutex);
             handoff->insertedWhilePaused=handoff->changed.wait_for(lock,200ms,[&]{return handoff->producerDone;});
             handoff->release=true;handoff->changed.notify_all();}
            producer.get();return true;
        });
    }
    EXPECT_CALL(*s.ril, SetRadioProtocol(testing::_, testing::_, testing::_)).Times(24)
        .WillRepeatedly([&](int slot, RadioProtocol protocol, const auto &event) {
            std::cout << "TRACE radio slot=" << slot << " session=" << protocol.sessionId
                << " phase=" << static_cast<int>(protocol.phase) << " modem=" << protocol.modemId << "\n";
            EXPECT_EQ(protocol.slotId, slot); EXPECT_EQ(protocol.modemId, slot);
            EXPECT_THAT(protocol.phase, testing::AnyOf(RadioProtocolPhase::RADIO_PROTOCOL_PHASE_CHECK,
                RadioProtocolPhase::RADIO_PROTOCOL_PHASE_COMPLETE)); // no UPDATE after failed CHECK
            {
                std::lock_guard<std::mutex> lock(s.mutex);
                phases[protocol.sessionId].emplace_back(slot, protocol.phase); ++requests; s.changed.notify_all();
            }
            if (protocol.phase == RadioProtocolPhase::RADIO_PROTOCOL_PHASE_CHECK) {
                auto response = std::make_shared<RadioResponseInfo>(); response->error = ErrType::ERR_GENERIC_FAILURE;
                if(interleaveHandoff && protocol.sessionId==3) {
                    std::optional<RealScenario::Pending> first;
                    {std::lock_guard<std::mutex> lock(handoff->mutex);
                     if(slot==0)handoff->first=RealScenario::Pending{slot,event->GetOwner(),event->GetInnerEventId()};
                     else {handoff->second=RealScenario::Pending{slot,event->GetOwner(),event->GetInnerEventId()};first=handoff->first;}}
                    if(first)RealScenario::Reply(*first,response);
                } else RealScenario::Reply({slot, event->GetOwner(), event->GetInnerEventId()}, response);
            } else {
                EXPECT_EQ(protocol.status, RadioProtocolStatus::RADIO_PROTOCOL_STATUS_FAIL);
                RealScenario::Reply({slot, event->GetOwner(), event->GetInnerEventId()}, std::make_shared<RadioProtocol>(protocol));
            }
            return 0;
        });
    EXPECT_EQ(s.core.SetPrimarySlotId(1), TELEPHONY_ERR_LOCAL_PTR_NULL);
    if(stopDuringRetry) {
        bool pending=false;
        for(const auto &q:SimHost::GetQueueEvidence())
            pending|=q.name=="MultiSimController" && q.pending>0;
        EXPECT_TRUE(pending) << "STOP_MUST_BEGIN_WITH_ORIGINAL_RETRY_PENDING";
        EXPECT_TRUE(s.manager->Stop());EXPECT_TRUE(s.manager->IsStopped());
        testing::Test::RecordProperty("stop_started_with_queued_retry",pending?"true":"false");
    }
    if (std::getenv("SIM_HOST_INJECT_C1_ASSERT")) {
        ASSERT_TRUE(false) << "INJECTED_C1_FATAL_ASSERT";
    }
    {
        std::lock_guard<std::mutex> lock(s.mutex);
        EXPECT_EQ(s.parametersDb["persist.telephony.MainSlotId"], "0") << "ROLLBACK_SLOT";
        EXPECT_EQ(s.parametersDb["persist.telephony.MainCard.Iccid"], "previous-parameter-value") << "ROLLBACK_ICCID";
        EXPECT_NE(s.parametersDb["persist.telephony.MainCellularDataSlotId"], "1");
    }
    {
        std::unique_lock<std::mutex> lock(s.mutex);
        ASSERT_TRUE(s.changed.wait_for(lock, 12s, [&] { return requests == 24; }));
        EXPECT_EQ(phases.size(), 6u); // original plus the five retries, each with a fresh session
        for (const auto &[session, sequence] : phases) {
            EXPECT_THAT(sequence, testing::ElementsAre(std::make_pair(0, RadioProtocolPhase::RADIO_PROTOCOL_PHASE_CHECK),
                std::make_pair(1, RadioProtocolPhase::RADIO_PROTOCOL_PHASE_CHECK),
                std::make_pair(0, RadioProtocolPhase::RADIO_PROTOCOL_PHASE_COMPLETE),
                std::make_pair(1, RadioProtocolPhase::RADIO_PROTOCOL_PHASE_COMPLETE)));
        }
    }
    if(coordinate.valid()) {
        EXPECT_TRUE(coordinate.get());
        testing::Test::RecordProperty("retry3_inserted_during_handoff",handoff->insertedWhilePaused?"true":"false");
    }
    const auto done = std::chrono::steady_clock::now() + 3s;
    while (s.manager->IsSetPrimarySlotIdInProgress() && std::chrono::steady_clock::now() < done)
        std::this_thread::sleep_for(1ms);
    EXPECT_FALSE(s.manager->IsSetPrimarySlotIdInProgress());
    std::lock_guard<std::mutex> lock(s.mutex);
    EXPECT_EQ(s.parametersDb["persist.telephony.MainSlotId"], "0") << "ROLLBACK_SLOT";
    EXPECT_EQ(s.parametersDb["persist.telephony.MainCard.Iccid"], "previous-parameter-value") << "ROLLBACK_ICCID";
    s.ExpectNotifications(false, 6, false);
    testing::Test::RecordProperty("business_assertions_before_cleanup", testing::Test::HasFailure() ? "FAIL" : "PASS");
}

TEST(RealSimPrimary, C1CheckFailureRestoresParametersAndExhaustsFiveRetries)
{VerifyC1FailureRetries();}
TEST(ConcurrencyRegression, C1RetriesDrainWhileStopping)
{VerifyC1FailureRetries(true);}
TEST(ConcurrencyRegression, C1RetryHandoffInterleaving)
{VerifyC1FailureRetries(false,true);}
}
int main(int argc, char **argv)
{
    testing::InitGoogleMock(&argc, argv);
    // Full initialization currently retains production subscription cycles.
    // Never reuse those live callbacks with another scenario's mock lifetime.
    const auto filter = testing::GTEST_FLAG(filter);
    if (!testing::GTEST_FLAG(list_tests) && (filter.find('*') != std::string::npos ||
        filter.find(':') != std::string::npos || filter.find('?') != std::string::npos)) {
        std::cerr << "Use run_primary_real.py or host.py: each real scenario requires its own process.\n";
        return 2;
    }
    return RUN_ALL_TESTS();
}

namespace {
struct HandoffState {
    std::mutex mutex;std::condition_variable changed;
    bool paused=false,release=false,producerStarted=false,producerDone=false,delivered=false;
};
class HandoffHandler final : public OHOS::Telephony::TelEventHandler {
public:
    explicit HandoffHandler(std::shared_ptr<HandoffState> state)
        : TelEventHandler("QueueHandoffRegression"),state_(std::move(state)) {}
    void ProcessEvent(const OHOS::AppExecFwk::InnerEvent::Pointer &event) override {
        if(event->GetInnerEventId()==3) {
            std::lock_guard<std::mutex> lock(state_->mutex);state_->delivered=true;state_->changed.notify_all();
        }
    }
private:std::shared_ptr<HandoffState> state_;
};
TEST(ConcurrencyRegression, QueueHandoffDoesNotDelayImmediateEvent)
{
    auto state=std::make_shared<HandoffState>();
    auto handler=std::make_shared<HandoffHandler>(state);
    ASSERT_TRUE(handler->SendEvent(2,45000)); // Retain real long-delay work behind the initial event.
    SimHost::SetLogObserver([state](const std::string &line) {
        if(line.find("SIM028_QUEUE_HANDOFF name=QueueHandoffRegression")==std::string::npos ||
           line.find("delay_us=4")==std::string::npos)return;
        std::unique_lock<std::mutex> lock(state->mutex);
        if(state->paused)return;
        state->paused=true;state->changed.notify_all();state->changed.wait(lock,[&]{return state->release;});
    });
    EXPECT_TRUE(handler->SendEvent(1));
    bool paused;
    {std::unique_lock<std::mutex> lock(state->mutex);paused=state->changed.wait_for(lock,3s,[&]{return state->paused;});}
    std::thread producer([handler,state] {
        {std::lock_guard<std::mutex> lock(state->mutex);state->producerStarted=true;state->changed.notify_all();}
        EXPECT_TRUE(handler->SendEvent(3));
        {std::lock_guard<std::mutex> lock(state->mutex);state->producerDone=true;state->changed.notify_all();}
    });
    bool insertedWhilePaused=false;
    {std::unique_lock<std::mutex> lock(state->mutex);
     EXPECT_TRUE(state->changed.wait_for(lock,3s,[&]{return state->producerStarted;}));
     // A bounded observation rendezvous, not a sleep or a business deadline change.
     insertedWhilePaused=state->changed.wait_for(lock,200ms,[&]{return state->producerDone;});
     state->release=true;state->changed.notify_all();}
    producer.join();SimHost::SetLogObserver({});
    bool delivered;
    {std::unique_lock<std::mutex> lock(state->mutex);delivered=state->changed.wait_for(lock,1s,[&]{return state->delivered;});}
    EXPECT_TRUE(paused);EXPECT_TRUE(delivered) << "IMMEDIATE_EVENT_STRANDED_BEHIND_STALE_45S_SNAPSHOT";
    testing::Test::RecordProperty("producer_inserted_during_handoff",insertedWhilePaused?"true":"false");
    EXPECT_TRUE(handler->StopEvents());std::weak_ptr<HandoffHandler> weak=handler;handler.reset();
    EXPECT_TRUE(weak.expired());EXPECT_TRUE(SimHost::AwaitSchedulerStopped(3s));
}
TEST(ConcurrencyRegression, CrossQueueStateSnapshotsAndSetter)
{
    auto handle=std::make_shared<OHOS::Telephony::SimStateHandle>(std::weak_ptr<OHOS::Telephony::SimStateManager>{});
    handle->SetSimState(OHOS::Telephony::SimState::SIM_STATE_UNKNOWN);
    std::promise<void> start;auto ready=start.get_future().share();std::atomic_uint reads{0};
    std::thread writer([&] {ready.wait();for(int i=0;i<20000;++i)
        handle->SetSimState(i%2?OHOS::Telephony::SimState::SIM_STATE_READY:OHOS::Telephony::SimState::SIM_STATE_LOCKED);});
    std::thread reader([&] {ready.wait();for(int i=0;i<20000;++i) {
        auto state=handle->GetSimState();EXPECT_TRUE(state==OHOS::Telephony::SimState::SIM_STATE_UNKNOWN ||
            state==OHOS::Telephony::SimState::SIM_STATE_READY || state==OHOS::Telephony::SimState::SIM_STATE_LOCKED);++reads;}});
    start.set_value();writer.join();reader.join();EXPECT_EQ(reads.load(),20000u);
    EXPECT_TRUE(handle->StopEvents());std::weak_ptr<OHOS::Telephony::SimStateHandle> weak=handle;handle.reset();
    EXPECT_TRUE(weak.expired());EXPECT_TRUE(SimHost::AwaitSchedulerStopped(3s));
}
}

namespace {
TEST(ConcurrencyRegression, C1CommunicationTimeoutThenFiveRetries)
{
    using namespace Sim028Host;
    std::map<int,std::vector<std::pair<int,RadioProtocolPhase>>> phases;
    unsigned requests=0;
    RealScenario s;
    ASSERT_TRUE(s.StartLockedCard());s.ClearObservations();s.Permit();
    {std::lock_guard<std::mutex> lock(s.mutex);
     s.parametersDb["persist.telephony.MainSlotId"]="0";
     s.parametersDb["persist.telephony.MainCard.Iccid"]="timeout-original-iccid";}
    EXPECT_CALL(*s.ril,SetPrimarySlot(testing::_,testing::_)).Times(0);
    EXPECT_CALL(*s.ril,GetRadioProtocol(testing::_,testing::_)).Times(2).WillRepeatedly([](int slot,const auto &event) {
        auto response=std::make_shared<RadioProtocol>();response->slotId=slot;response->modemId=slot;
        response->technology=slot==0?0x11:0x22;
        RealScenario::Reply({slot,event->GetOwner(),event->GetInnerEventId()},response);return 0;
    });
    s.manager->GetRadioProtocol(0);s.manager->GetRadioProtocol(1);
    const auto deadline=std::chrono::steady_clock::now()+3s;
    while(s.manager->GetRadioProtocolSlotIdByModemId(1)!=1 && std::chrono::steady_clock::now()<deadline)
        std::this_thread::yield();
    ASSERT_EQ(s.manager->GetRadioProtocolSlotIdByModemId(1),1);
    EXPECT_CALL(*s.ril,SetRadioProtocol(testing::_,testing::_,testing::_)).Times(22)
        .WillRepeatedly([&](int slot,RadioProtocol protocol,const auto &event) {
            {std::lock_guard<std::mutex> lock(s.mutex);
             ++requests;phases[protocol.sessionId].emplace_back(slot,protocol.phase);}
            std::cout<<"TIMEOUT_RETRY session="<<protocol.sessionId<<" phase="<<static_cast<int>(protocol.phase)
                <<" slot="<<slot<<" serial=NOT_CREATED_AT_ITelRilManager_MOCK_BOUNDARY\n";
            EXPECT_EQ(protocol.slotId,slot);EXPECT_EQ(protocol.modemId,slot);
            if(protocol.sessionId==1) {EXPECT_EQ(protocol.phase,RadioProtocolPhase::RADIO_PROTOCOL_PHASE_CHECK);return 0;}
            if(protocol.phase==RadioProtocolPhase::RADIO_PROTOCOL_PHASE_CHECK) {
                auto error=std::make_shared<RadioResponseInfo>();error->error=ErrType::ERR_GENERIC_FAILURE;
                RealScenario::Reply({slot,event->GetOwner(),event->GetInnerEventId()},error);
            } else {
                EXPECT_EQ(protocol.phase,RadioProtocolPhase::RADIO_PROTOCOL_PHASE_COMPLETE);
                EXPECT_EQ(protocol.status,RadioProtocolStatus::RADIO_PROTOCOL_STATUS_FAIL);
                RealScenario::Reply({slot,event->GetOwner(),event->GetInnerEventId()},std::make_shared<RadioProtocol>(protocol));
            }
            return 0;
        });
    auto start=std::chrono::steady_clock::now();
    EXPECT_EQ(s.core.SetPrimarySlotId(1),TELEPHONY_ERR_LOCAL_PTR_NULL);
    EXPECT_GE(std::chrono::steady_clock::now()-start,44s);
    EXPECT_TRUE(s.manager->Stop());EXPECT_TRUE(s.manager->IsStopped());
    std::lock_guard<std::mutex> lock(s.mutex);
    EXPECT_EQ(requests,22u);EXPECT_EQ(phases.size(),6u);EXPECT_EQ(phases.count(2),0u);
    for(const auto &[session,sequence]:phases) {
        if(session==1)EXPECT_THAT(sequence,testing::ElementsAre(
            std::make_pair(0,RadioProtocolPhase::RADIO_PROTOCOL_PHASE_CHECK),
            std::make_pair(1,RadioProtocolPhase::RADIO_PROTOCOL_PHASE_CHECK)));
        else EXPECT_THAT(sequence,testing::ElementsAre(
            std::make_pair(0,RadioProtocolPhase::RADIO_PROTOCOL_PHASE_CHECK),
            std::make_pair(1,RadioProtocolPhase::RADIO_PROTOCOL_PHASE_CHECK),
            std::make_pair(0,RadioProtocolPhase::RADIO_PROTOCOL_PHASE_COMPLETE),
            std::make_pair(1,RadioProtocolPhase::RADIO_PROTOCOL_PHASE_COMPLETE)));
    }
    EXPECT_EQ(s.parametersDb["persist.telephony.MainSlotId"],"0");
    EXPECT_EQ(s.parametersDb["persist.telephony.MainCard.Iccid"],"timeout-original-iccid");
    s.ExpectNotifications(false,6,false);
    testing::Test::RecordProperty("business_assertions_before_cleanup",testing::Test::HasFailure()?"FAIL":"PASS");
    testing::Test::RecordProperty("timeout_seconds",45);
}
}
