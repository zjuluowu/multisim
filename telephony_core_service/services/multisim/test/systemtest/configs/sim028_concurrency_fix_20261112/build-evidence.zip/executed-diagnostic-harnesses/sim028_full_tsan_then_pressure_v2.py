import pathlib,json,importlib.util,hashlib,concurrent.futures,sys
s=pathlib.Path('/mnt/e/github/multisim/telephony_core_service/services/multisim/test/systemtest');w=pathlib.Path(json.load(open('/tmp/sim028-concurrency-current.json'))['work']);spec=importlib.util.spec_from_file_location('ci',s/'tools/ci_sim028.py');ci=importlib.util.module_from_spec(spec);spec.loader.exec_module(ci);out=w/'full-tsan-and-pressure-v2';out.mkdir();b=w/'phase-thread/build/sim_primary_slot_real_test';names=ci.discovery(b,out,True);summary={'binary_sha256':hashlib.sha256(b.read_bytes()).hexdigest(),'full_cases':[],'pressure':[],'status':'RUNNING'}
def run(c,i,prefix):
 label=prefix+'-'+c.replace('.','_')+'-'+str(i);d=out/label;d.mkdir();xml=d/'case.xml';step=ci.command([b,'--gtest_filter='+c,'--gtest_output=xml:'+str(xml)],d/'case.log',d,ci.test_env(d,True,'thread'),120);r=ci.read_case(xml,c,step['exit_code']);r.update(step);r['admission']=ci.evaluate([r],[c],{});ci.save(d/'result.json',r);return r
for i,c in enumerate(names):
 summary['full_cases'].append(run(c,i,'full'));ci.save(out/'result.json',summary)
summary['full_status']='PASS' if all(r['admission']['status']=='PASS' for r in summary['full_cases']) else 'FAIL';ci.save(out/'result.json',summary)
if summary['full_status']!='PASS':summary['status']='FAIL';ci.save(out/'result.json',summary);print('Full TSan failed; pressure not started');sys.exit(1)
cases=['RealSimPrimary.BDirectRilFailureKeepsPreviousPrimary','ConcurrencyRegression.CrossQueueStateSnapshotsAndSetter','RealSimPrimary.C1CheckFailureRestoresParametersAndExhaustsFiveRetries','ConcurrencyRegression.C1RetryHandoffInterleaving','ConcurrencyRegression.C1RetriesDrainWhileStopping'];work=[(c,i) for c in cases for i in range(50)]+[(c,i) for c in ['ShutdownExtra.C1StopAtCheck','ShutdownExtra.C1StopAtUpdate','ShutdownExtra.C1StopAtComplete'] for i in range(10)]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for row in pool.map(lambda v:run(v[0],v[1],'pressure'),work):summary['pressure'].append(row);ci.save(out/'result.json',summary)
summary['status']='PASS' if all(r['admission']['status']=='PASS' for r in summary['pressure']) else 'FAIL';ci.save(out/'result.json',summary);print('Full',len(names),'pressure',len(work),summary['status']);sys.exit(summary['status']!='PASS')
