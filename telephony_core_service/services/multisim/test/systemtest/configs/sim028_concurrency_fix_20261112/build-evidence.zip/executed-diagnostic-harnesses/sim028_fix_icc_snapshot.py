from pathlib import Path
import json
w=Path(json.load(open('/tmp/sim028-concurrency-current.json'))['work']);p=w/'ci/repo/telephony_core_service/services/sim/src/sim_state_handle.cpp';s=p.read_text();s=s.replace('    bool has = true;\n    if (iccState_.simStatus_ == ICC_CARD_ABSENT ||\n        (iccState_.simStatus_ == ICC_CONTENT_UNKNOWN && CoreManagerInner::GetInstance().IsEsim(slotId_))) {','''    bool has = true;
    int32_t cardStatus;
    {
        std::lock_guard<ffrt::mutex> lock(externalStateMutex_);
        cardStatus = iccState_.simStatus_;
    }
    if (cardStatus == ICC_CARD_ABSENT ||
        (cardStatus == ICC_CONTENT_UNKNOWN && CoreManagerInner::GetInstance().IsEsim(slotId_))) {''');s=s.replace('    iccState_ = ar;','''    {
        // Publish the value snapshot without holding this lock across callbacks.
        std::lock_guard<ffrt::mutex> lock(externalStateMutex_);
        iccState_ = ar;
    }''');needle='    if (iccState_.simStatus_ != ICC_CARD_ABSENT) {';assert needle in s;s=s.replace(needle,'''    bool present;
    {
        std::lock_guard<ffrt::mutex> lock(externalStateMutex_);
        present = iccState_.simStatus_ != ICC_CARD_ABSENT;
    }
    if (present) {''');(w/'pending/sim_state_handle-v3.cpp').write_text(s)
s=Path('/tmp/sim028_export_increment_v2.py').read_text();s=s.replace("b=(repo/n).read_bytes();minimal=", "b=(w/'pending/sim_state_handle-v3.cpp').read_bytes() if n.endswith('src/sim_state_handle.cpp') else (repo/n).read_bytes();minimal=");s=s.replace('production-increment-v2.patch','production-increment-v3.patch').replace('test-increment-v2.patch','test-increment-v3.patch').replace('increment-manifest-v2.json','increment-manifest-v3.json').replace("check=w/'increment-check-v2'","check=w/'increment-check-v3'");Path('/tmp/sim028_export_increment_v3.py').write_text(s)
print('IccState full copy and all three state accesses use the existing snapshot lock; no lock across IsEsim/RIL')
