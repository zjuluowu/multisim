from pathlib import Path
import json,subprocess,hashlib
root=Path.cwd();w=Path(json.load(open('/tmp/sim028-concurrency-current.json'))['work']);n='telephony_core_service/services/sim/src/multi_sim_controller.cpp';p=w/'increment-base'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/n).read_bytes().replace(b'\r\n',b'\n'));ad=root/'telephony_core_service/services/multisim/test/systemtest/primary_slot/lifecycle/admission';
for patch in ['production-minimal.patch','test-guard.patch']:subprocess.run(['git','apply','--include='+n,str(ad/patch)],cwd=w/'increment-base',check=True)
row=next(r for r in json.loads((ad/'patch-manifest.json').read_text())['files'] if r['path']==n);assert hashlib.sha256(p.read_bytes()).hexdigest()==row['candidate_sha256'];names=json.loads((w/'increment-files.json').read_text());names.append(n);(w/'increment-files.json').write_text(json.dumps(names,indent=2))
s=(w/'ci/repo'/n).read_text();old='''    primarySimId_ = localCacheInfo_[slotId].simId;
    primarySlotId_ = slotId;
    lock.unlock();
    TELEPHONY_LOGI("Announce main simId %{public}d", primarySimId_);
    multiSimHelper_->AnnouncePrimarySimIdChanged(primarySimId_, slotId);''';new='''    primarySimId_ = localCacheInfo_[slotId].simId;
    primarySlotId_ = slotId;
    const int32_t simId = primarySimId_;
    lock.unlock();
    TELEPHONY_LOGI("Announce main simId %{public}d", simId);
    multiSimHelper_->AnnouncePrimarySimIdChanged(simId, slotId);''';assert old in s;s=s.replace(old,new)
s=s.replace('void MultiSimController::SendDefaultCellularDataBroadCast(int32_t slotId)\n{','void MultiSimController::SendDefaultCellularDataBroadCast(int32_t slotId)\n{\n    std::unique_lock<ffrt::shared_mutex> lock(mutex_);');old='''    defaultCellularSimId_ = localCacheInfo_[slotId].simId;
    TELEPHONY_LOGI("Announce default cellular data simId %{public}d", defaultCellularSimId_);
    AnnounceDefaultCellularDataSimIdChanged(defaultCellularSimId_);''';new='''    defaultCellularSimId_ = localCacheInfo_[slotId].simId;
    const int32_t simId = defaultCellularSimId_;
    lock.unlock(); // Publish external notifications from the coherent value snapshot.
    TELEPHONY_LOGI("Announce default cellular data simId %{public}d", simId);
    AnnounceDefaultCellularDataSimIdChanged(simId);''';assert old in s;s=s.replace(old,new);(w/'pending/multi_sim_controller-v4.cpp').write_text(s)
s=Path('/tmp/sim028_export_increment_v3.py').read_text();s=s.replace("else (repo/n).read_bytes();minimal=", "else (w/'pending/multi_sim_controller-v4.cpp').read_bytes() if n.endswith('src/multi_sim_controller.cpp') else (repo/n).read_bytes();minimal=");s=s.replace('production-increment-v3.patch','production-increment-v4.patch').replace('test-increment-v3.patch','test-increment-v4.patch').replace('increment-manifest-v3.json','increment-manifest-v4.json').replace("check=w/'increment-check-v3'","check=w/'increment-check-v4'").replace('Production4/test5 union8','Production5/test5 union9');Path('/tmp/sim028_export_increment_v4.py').write_text(s)
