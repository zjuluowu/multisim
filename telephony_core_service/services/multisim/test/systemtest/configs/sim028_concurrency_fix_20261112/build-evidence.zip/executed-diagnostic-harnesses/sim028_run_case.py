import pathlib,json,sys,importlib.util,hashlib
s=pathlib.Path('/mnt/e/github/multisim/telephony_core_service/services/multisim/test/systemtest');w=pathlib.Path(json.load(open('/tmp/sim028-concurrency-current.json'))['work']);spec=importlib.util.spec_from_file_location('ci',s/'tools/ci_sim028.py');ci=importlib.util.module_from_spec(spec);spec.loader.exec_module(ci)
profile,case,label=sys.argv[1:4];out=w/label;out.mkdir();binary=w/('phase-'+profile)/'build/sim_primary_slot_real_test';env=ci.test_env(out,True,profile);env['SIM_HOST_TRACE']='1';
if len(sys.argv)>4:env[sys.argv[4]]='1'
step=ci.command([binary,'--gtest_filter='+case,'--gtest_output=xml:'+str(out/'case.xml')],out/'case.log',out,env,150);row=ci.read_case(out/'case.xml',case,step['exit_code']);row.update(step);row['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest();ci.save(out/'result.json',row);print(label,row['status'],row['exit_code'],row.get('properties'))
