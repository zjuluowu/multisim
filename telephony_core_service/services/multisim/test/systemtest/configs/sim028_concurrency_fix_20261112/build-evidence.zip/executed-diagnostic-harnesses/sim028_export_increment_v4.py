from pathlib import Path
import json,hashlib,re,difflib,subprocess,shutil
root=Path('/mnt/e/github/multisim');s=root/'telephony_core_service/services/multisim/test/systemtest';ad=s/'primary_slot/lifecycle/admission';out=s/'configs/sim028_concurrency_fix_20261112';out.mkdir(exist_ok=True);w=Path(json.load(open('/tmp/sim028-concurrency-current.json'))['work']);repo=w/'ci/repo';base=w/'increment-base';names=json.loads((w/'increment-files.json').read_text());p=repo/'telephony_core_service/services/multisim/test/systemtest/stubs/ffrt_runtime.cpp';t=p.read_text();t=t if '    if (!hasLogObserver.load(std::memory_order_acquire)) return;' in t else t.replace('void ObserveHostLog(const std::string &line) {','void ObserveHostLog(const std::string &line) {\n    if (!hasLogObserver.load(std::memory_order_acquire)) return;');p.write_text(t)
# No diagnostic registry mutex on the ordinary execution path.
def sha(b):return hashlib.sha256(b).hexdigest()
def delta(n,a,b):
 if a==b:return ''
 return 'diff --git a/'+n+' b/'+n+'\n'+''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+n,tofile='b/'+n))
prod=[];test=[];files=[]
for n in names:
 a=(base/n).read_bytes();b=(w/'pending/sim_state_handle-v3.cpp').read_bytes() if n.endswith('src/sim_state_handle.cpp') else (w/'pending/multi_sim_controller-v4.cpp').read_bytes() if n.endswith('src/multi_sim_controller.cpp') else (repo/n).read_bytes();minimal=b if n.startswith(('telephony_core_service/services/sim/','telephony_core_service/utils/')) else a
 if n.endswith('tel_event_queue.cpp'):
  minimal=re.sub(rb'^[ \t]*#ifdef TELEPHONY_HOST_LIFETIME_AUDIT\n.*?^[ \t]*#endif\n',b'',minimal,flags=re.S|re.M)
 prod.append(delta(n,a,minimal));test.append(delta(n,minimal,b));files.append({'path':n,'production_changed':a!=minimal,'test_changed':minimal!=b,'base_sha256':sha(a),'production_sha256':sha(minimal),'candidate_sha256':sha(b)})
(out/'production-increment-v4.patch').write_text(''.join(prod));(out/'test-increment-v4.patch').write_text(''.join(test));manifest={'base_head':'77e3dc4e27dfe33ac728f225843b86b038914f6c','base_patches':{n:sha((ad/n).read_bytes()) for n in ('production-minimal.patch','test-guard.patch')},'apply_order':['admission/production-minimal.patch','admission/test-guard.patch','production-increment-v4.patch','test-increment-v4.patch'],'production_files':[r['path'] for r in files if r['production_changed']],'files':files};(out/'increment-manifest-v4.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
check=w/'increment-check-v4';check.mkdir()
for n in names:
 p=check/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((base/n).read_bytes())
for n in ('production-increment-v4.patch','test-increment-v4.patch'):
 subprocess.run(['git','apply','--check',str(out/n)],cwd=check,check=True);subprocess.run(['git','apply',str(out/n)],cwd=check,check=True)
assert all(sha((check/r['path']).read_bytes())==r['candidate_sha256'] for r in files)
print(out);print('Production5/test5 union9 apply+SHA PASS')
