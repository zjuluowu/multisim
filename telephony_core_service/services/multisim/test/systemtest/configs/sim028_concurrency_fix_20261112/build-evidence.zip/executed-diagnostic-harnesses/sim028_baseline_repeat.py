import json, pathlib,importlib.util,sys,hashlib
root=pathlib.Path('/mnt/e/github/multisim');s=root/'telephony_core_service/services/multisim/test/systemtest';w=pathlib.Path(json.load(open('/tmp/sim028-concurrency-current.json'))['work']);spec=importlib.util.spec_from_file_location('ci',s/'tools/ci_sim028.py');ci=importlib.util.module_from_spec(spec);spec.loader.exec_module(ci);b=json.load(open(w/'baseline-binaries.json'));profile=sys.argv[1];out=w/('before-'+profile);out.mkdir();case='RealSimPrimary.BDirectRilFailureKeepsPreviousPrimary' if profile=='thread' else 'RealSimPrimary.C1CheckFailureRestoresParametersAndExhaustsFiveRetries';records=[]
for i in range(10 if profile=='thread' else 5):
 xml=out/f'{i}.xml';step=ci.command([b[profile]['binary'],'--gtest_filter='+case,'--gtest_output=xml:'+str(xml)],out/f'{i}.log',out,ci.test_env(out,True,profile),120);r=ci.read_case(xml,case,step['exit_code']);r.update(step);records.append(r);ci.save(out/'result.json',records)
 if step['exit_code']:break
print(profile,len(records),[r['exit_code'] for r in records])
