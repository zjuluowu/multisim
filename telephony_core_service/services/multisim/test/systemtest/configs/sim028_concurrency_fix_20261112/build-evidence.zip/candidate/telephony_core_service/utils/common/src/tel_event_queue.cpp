/*
 * Copyright (C) 2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "tel_event_queue.h"

#include "tel_event_handler.h"
#include "telephony_log_wrapper.h"
#ifdef TELEPHONY_HOST_LIFETIME_AUDIT
namespace SimHost { void ObserveHostLog(const std::string &line); }
#endif

namespace OHOS {
namespace Telephony {
namespace {
enum class TelPriority : uint32_t { IMMEDIATE = 0, HIGH, LOW };
}

static constexpr int PRINT_INTELVAL_MINUTES = 5;
constexpr int DEACTIVE_DATA_CALL = 31;
TelEventQueue::TelEventQueue(const std::string &name) : name_(name)
{
    TELEPHONY_LOGI("%{public}s create", name_.c_str());
    name_ = std::string(name_.c_str());
    queue_ = std::make_shared<ffrt::queue>(name_.c_str());
}

TelEventQueue::~TelEventQueue()
{
    TELEPHONY_LOGI("%{public}s destroy", name_.c_str());
    RemoveAllEvents();
    ClearCurrentTask(true);
    if (!queue_) {
        return;
    }
    if (!curTask_) {
        return;
    }
    TELEPHONY_LOGD("%{public}s need to wait", name_.c_str());
    queue_->wait(curTask_);
    curTask_ = ffrt::task_handle();
    std::unique_lock<ffrt::mutex> lock(taskCtx_);
    queue_ = nullptr;
}

AppExecFwk::InnerEvent::TimePoint TelEventQueue::GetCurHandleTime()
{
    std::unique_lock<ffrt::mutex> lock(memberCtx_);
    return curHandleTime_;
}

void TelEventQueue::SetCurHandleTime(AppExecFwk::InnerEvent::TimePoint handleTime)
{
    std::unique_lock<ffrt::mutex> lock(memberCtx_);
    curHandleTime_ = handleTime;
}

bool TelEventQueue::Submit(AppExecFwk::InnerEvent::Pointer &event, AppExecFwk::EventQueue::Priority priority)
{
    std::lock_guard<ffrt::mutex> admission(admissionMutex_);
    if(closed_.load() || lifecycle_->Sealed()) return false;
    InsertEventsInner(event, priority);
    if (GetHandleTime() < GetCurHandleTime()) {
        GetNextQueueId();
        ClearCurrentTask(false);
        SubmitInner(queueId_.load());
    }
    lifecycle_->Pulse();
    return true;
}

uint32_t TelEventQueue::ToTelPriority(AppExecFwk::EventQueue::Priority priority)
{
    if (priority == AppExecFwk::EventQueue::Priority::IMMEDIATE) {
        return static_cast<uint32_t>(TelPriority::IMMEDIATE);
    }
    if (priority == AppExecFwk::EventQueue::Priority::HIGH) {
        return static_cast<uint32_t>(TelPriority::HIGH);
    }
    return static_cast<uint32_t>(TelPriority::LOW);
}

void TelEventQueue::InsertEventsInner(AppExecFwk::InnerEvent::Pointer &event, AppExecFwk::EventQueue::Priority priority)
{
    if (event == nullptr) {
        return;
    }
    std::unique_lock<ffrt::mutex> lock(eventCtx_);
    auto &events = eventLists_[ToTelPriority(priority)].events;
    auto f = [](const AppExecFwk::InnerEvent::Pointer &first, const AppExecFwk::InnerEvent::Pointer &second) {
        if (!first || !second) {
            return false;
        }
        return first->GetHandleTime() < second->GetHandleTime();
    };
    auto it = std::upper_bound(events.begin(), events.end(), event, f);
    auto innerEventId = event->GetInnerEventId();
    events.insert(it, std::move(event));
    eventStats_.CalculationInsertQueueEvents();
    eventStats_.PrintEventStats(name_);
    TELEPHONY_LOGD(
        "%{public}s InsertEventsInner eventId %{public}d finish", name_.c_str(), static_cast<int32_t>(innerEventId));
}

void TelEventQueue::ClearCurrentTask(bool isNeedEnd)
{
    std::unique_lock<ffrt::mutex> lock(taskCtx_);
    if (!curTask_ || !queue_) {
        return;
    }
    if(queue_->cancel(curTask_)==0) submitted_.erase(currentToken_);
    if (isNeedEnd) {
        GetNextQueueId();
        return;
    }
    curTask_ = ffrt::task_handle();
    TELEPHONY_LOGD("%{public}s cancel current task", name_.c_str());
}

void TelEventQueue::SubmitInner(int32_t queueId)
{
    if (!queue_) {
        TELEPHONY_LOGE("%{public}s queue is nullptr", name_.c_str());
        return;
    }
    auto handleTime = GetHandleTime();
    if (handleTime == AppExecFwk::InnerEvent::TimePoint::max()) {
        TELEPHONY_LOGD("%{public}s SubmitInner has no task", name_.c_str());
        return;
    }
    int64_t delayTime = 0;
    AppExecFwk::InnerEvent::TimePoint now = AppExecFwk::InnerEvent::Clock::now();
    if (handleTime > now) {
        delayTime = std::chrono::duration_cast<std::chrono::microseconds>(handleTime - now).count();
    }
    #ifdef TELEPHONY_HOST_LIFETIME_AUDIT
    SimHost::ObserveHostLog("SIM028_QUEUE_HANDOFF name="+name_+" revision="+std::to_string(queueId)+
        " delay_us="+std::to_string(delayTime));
    #endif
    SubmitToFFRT(queueId, handleTime, delayTime);
}

int32_t TelEventQueue::GetNextQueueId()
{
    if (queueId_ >= INT32_MAX) {
        queueId_ = 1;
    }
    return queueId_++;
}

void TelEventQueue::SubmitToFFRT(int32_t queueId, AppExecFwk::InnerEvent::TimePoint handleTime, int64_t delayTime)
{
    std::unique_lock<ffrt::mutex> lock(taskCtx_);
    if (closed_.load() || queueId != queueId_.load()) {
        TELEPHONY_LOGD("%{public}s task no need to submit", name_.c_str());
        SetCurHandleTime(AppExecFwk::InnerEvent::TimePoint::max());
        return;
    }
    SetCurHandleTime(handleTime);
    std::weak_ptr<TelEventQueue> weak = shared_from_this();
    uint64_t token=++taskToken_;currentToken_=token;
    curTask_ = queue_->submit_h(
        [weak, queueId = queueId, token]() {
            auto thiz = weak.lock();
            if (thiz == nullptr) {
                return;
            }
            if(thiz->closed_.load()) return;
            TelLifecycle::Lease callback(thiz->lifecycle_,TelLifecycle::Kind::Callback);
            if(!callback) return;
            bool isNeedSubmit = true;
            auto event = thiz->PopEvent(queueId, isNeedSubmit);
            std::shared_ptr<TelEventHandler> handler = nullptr;
            if (event) {
                handler = std::static_pointer_cast<TelEventHandler>(event->GetOwner());
                if (event->GetInnerEventId() == DEACTIVE_DATA_CALL) {
                    TELEPHONY_LOGI("RADIO_RIL_DEACTIVATE_DATA_CALL ffrt");
                }
            }
            bool continuation=false;
            if(event) {std::lock_guard<ffrt::mutex> lock(thiz->taskCtx_);continuation=thiz->continuations_.count(event->GetInnerEventId());}
            TelLifecycle::Context context(thiz->lifecycle_,continuation);
            if (event && handler) {
                TELEPHONY_LOGD("%{public}s ProcessEvent eventId %{public}d", thiz->name_.c_str(),
                    static_cast<uint32_t>(event->GetInnerEventId()));
                handler->ProcessEvent(event);
                thiz->eventStats_.CalculationExecutedEvents();
            }
            thiz->Finished(token);
            if (!isNeedSubmit) {
                TELEPHONY_LOGD("%{public}s task no need to submit", thiz->name_.c_str());
                return;
            }
            // Serialize the next wake-up snapshot with external insertion. An
            // immediate reply must not arrive between selecting a future timer
            // and publishing that timer as the current scheduled task.
            std::lock_guard<ffrt::mutex> admission(thiz->admissionMutex_);
            thiz->SubmitInner(queueId);
        },
        ffrt::task_attr().delay(delayTime));
    submitted_.emplace(token,curTask_);
        eventStats_.CalculationSubmitToFFRTEvents();
}

void TelEventQueue::RemoveEvent(uint32_t innerEventId)
{
    std::unique_lock<ffrt::mutex> lock(eventCtx_);
    auto filter = [innerEventId](const AppExecFwk::InnerEvent::Pointer &p) {
        if (p == nullptr) {
            return false;
        }
        return p->GetInnerEventId() == innerEventId;
    };
    for (uint32_t i = 0; i < EVENT_QUEUE_NUM; ++i) {
        eventLists_[i].events.remove_if(filter);
    }
    if (IsEmpty()) {
        SetCurHandleTime(AppExecFwk::InnerEvent::TimePoint::max());
    }
    eventStats_.CalculationRemovedEvents(1);
    TELEPHONY_LOGD("%{public}s remove eventId %{public}d finish", name_.c_str(), innerEventId);
}

bool TelEventQueue::HasInnerEvent(uint32_t innerEventId)
{
    std::unique_lock<ffrt::mutex> lock(eventCtx_);
    auto filter = [innerEventId](
                      const AppExecFwk::InnerEvent::Pointer &p) { return p->GetInnerEventId() == innerEventId; };
    for (uint32_t i = 0; i < EVENT_QUEUE_NUM; ++i) {
        std::list<AppExecFwk::InnerEvent::Pointer>::iterator iter =
            std::find_if(eventLists_[i].events.begin(), eventLists_[i].events.end(), filter);
        if (iter != eventLists_[i].events.end()) {
            return true;
        }
    }
    return false;
}

void TelEventQueue::RemoveAllEvents()
{
    std::array<EventList,EVENT_QUEUE_NUM> retired;
    {
        std::unique_lock<ffrt::mutex> lock(eventCtx_);
        unsigned count=0;for(const auto &list:eventLists_)count+=list.events.size();
        retired.swap(eventLists_);SetCurHandleTime(AppExecFwk::InnerEvent::TimePoint::max());
        eventStats_.CalculationRemovedEvents(count);
    }
}

bool TelEventQueue::IsEmpty()
{
    for (uint32_t i = 0; i < EVENT_QUEUE_NUM; ++i) {
        if (!eventLists_[i].events.empty()) {
            return false;
        }
    }
    return true;
}

AppExecFwk::InnerEvent::Pointer TelEventQueue::PopEvent(int32_t queueId, bool &isNeedSubmit)
{
    std::unique_lock<ffrt::mutex> lock(eventCtx_);
    if (IsEmpty() || queueId != queueId_.load()) {
        isNeedSubmit = false;
        SetCurHandleTime(AppExecFwk::InnerEvent::TimePoint::max());
        return AppExecFwk::InnerEvent::Pointer(nullptr, nullptr);
    }
    uint32_t priorityIndex = GetPriorityIndex();
    AppExecFwk::InnerEvent::Pointer event = std::move(eventLists_[priorityIndex].events.front());
    eventLists_[priorityIndex].events.pop_front();
    if (IsEmpty()) {
        isNeedSubmit = false;
        SetCurHandleTime(AppExecFwk::InnerEvent::TimePoint::max());
    }
    return event;
}

AppExecFwk::InnerEvent::TimePoint TelEventQueue::GetHandleTime()
{
    std::unique_lock<ffrt::mutex> lock(eventCtx_);
    if (IsEmpty()) {
        return AppExecFwk::InnerEvent::TimePoint::max();
    }
    return eventLists_[GetPriorityIndex()].events.front()->GetHandleTime();
}

uint32_t TelEventQueue::GetPriorityIndex()
{
    AppExecFwk::InnerEvent::TimePoint now = AppExecFwk::InnerEvent::Clock::now();
    AppExecFwk::InnerEvent::TimePoint needWakeUpTime = AppExecFwk::InnerEvent::TimePoint::max();
    uint32_t priorityIndex = 0;
    for (uint32_t i = 0; i < EVENT_QUEUE_NUM; ++i) {
        if (eventLists_[i].events.empty()) {
            continue;
        }
        auto handleTime = eventLists_[i].events.front()->GetHandleTime();
        if (handleTime <= now) {
            priorityIndex = i;
            break;
        }
        if (handleTime < needWakeUpTime) {
            needWakeUpTime = handleTime;
            priorityIndex = i;
        }
    }
    return priorityIndex;
}

void TelEventQueue::EventStats::CalculationInsertQueueEvents()
{
    totalHandledEvents++;
    currentQueueEvents++;
}

void TelEventQueue::EventStats::CalculationSubmitToFFRTEvents()
{
    if (currentQueueEvents <= 0) {
        currentQueueEvents = 1;
    }
    submitedToFFRTEvents++;
    currentQueueEvents--;
}

void TelEventQueue::EventStats::CalculationExecutedEvents()
{
    executedEvents++;
}

void TelEventQueue::EventStats::CalculationRemovedEvents(int count)
{
    removedEvents += count;
}

void TelEventQueue::EventStats::PrintEventStats(std::string &name)
{
    AppExecFwk::InnerEvent::TimePoint now = AppExecFwk::InnerEvent::Clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::minutes>(now - lastPrintTime_);
    if (duration.count() < PRINT_INTELVAL_MINUTES) {
        return;
    }
    lastPrintTime_ = now;
    TELEPHONY_LOGI(
        "%{public}s, totalHandledEvents %{public}llu, currentQueueEvents %{public}llu,"
        " submitedToFFRTEvents %{public}llu, executedEvents %{public}llu, removedEvents %{public}llu",
        name.c_str(),
        static_cast<unsigned long long>(totalHandledEvents.load()),
        static_cast<unsigned long long>(currentQueueEvents.load()),
        static_cast<unsigned long long>(submitedToFFRTEvents.load()),
        static_cast<unsigned long long>(executedEvents.load()),
        static_cast<unsigned long long>(removedEvents.load())
    );
}

} // namespace Telephony
} // namespace OHOS
namespace OHOS { namespace Telephony {
bool TelEventQueue::Stop()
{
    if(lifecycle_->InContext()) return false;
    {std::unique_lock<ffrt::mutex> lock(admissionMutex_);if(stopping_ && !(TelLifecycle::CurrentKey()<stopOwner_) && !(stopOwner_<TelLifecycle::CurrentKey()))return false;
    admissionChanged_.wait(lock,[&]{return !stopping_;});if(stopped_)return true;stopping_=true;stopOwner_=TelLifecycle::CurrentKey();closed_=true;}
    RemoveAllEvents();
    std::vector<ffrt::task_handle> tasks; std::shared_ptr<ffrt::queue> queue;
    {std::lock_guard<ffrt::mutex> lock(taskCtx_);queue=queue_;for(auto &p:submitted_)tasks.push_back(p.second);if(curTask_)tasks.push_back(curTask_);}
    if(queue) {for(auto &task:tasks)queue->cancel(task);for(auto &task:tasks)queue->wait(task);}
    {std::lock_guard<ffrt::mutex> lock(taskCtx_);submitted_.clear();curTask_=ffrt::task_handle();queue_.reset();}
    queue.reset();
    {std::lock_guard<ffrt::mutex> lock(admissionMutex_);stopping_=false;stopped_=true;}admissionChanged_.notify_all();return true;
}
} }
