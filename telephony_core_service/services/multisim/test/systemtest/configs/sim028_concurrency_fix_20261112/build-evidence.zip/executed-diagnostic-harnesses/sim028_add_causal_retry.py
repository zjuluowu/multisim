import pathlib,json
w=pathlib.Path(json.load(open('/tmp/sim028-concurrency-current.json'))['work']);p=w/'pending/real_test_more.cpp';s=p.read_text();s=s.replace('void VerifyC1FailureRetries(bool stopDuringRetry = false)','void VerifyC1FailureRetries(bool stopDuringRetry = false, bool interleaveHandoff = false)');pos=s.index('void VerifyC1FailureRetries');a,b=s[:pos],s[pos:];needle='    RealScenario s;';b=b.replace(needle,'''    struct RetryHandoff {
        std::mutex mutex;std::condition_variable changed;
        bool paused=false,release=false,producerDone=false,insertedWhilePaused=false;
        std::optional<RealScenario::Pending> first,second;
    };
    auto handoff=std::make_shared<RetryHandoff>();
    RealScenario s;''',1)
needle='    EXPECT_CALL(*s.ril, SetRadioProtocol(testing::_, testing::_, testing::_)).Times(24)';b=b.replace(needle,'''    struct ClearObserver {~ClearObserver(){SimHost::SetLogObserver({});}} clearObserver;
    std::future<bool> coordinate;
    if(interleaveHandoff) {
        SimHost::SetLogObserver([handoff](const std::string &line) {
            if(line.find("SIM028_QUEUE_HANDOFF name=RadioProtocolController")==std::string::npos ||
               line.find("delay_us=4")==std::string::npos)return;
            std::unique_lock<std::mutex> lock(handoff->mutex);
            if(!handoff->second || handoff->paused)return;
            handoff->paused=true;handoff->changed.notify_all();
            handoff->changed.wait(lock,[&]{return handoff->release;});
        });
        coordinate=std::async(std::launch::async,[handoff] {
            RealScenario::Pending pending;
            {std::unique_lock<std::mutex> lock(handoff->mutex);
             if(!handoff->changed.wait_for(lock,10s,[&]{return handoff->paused;}))return false;
             pending=*handoff->second;}
            auto producer=std::async(std::launch::async,[handoff,pending] {
                auto error=std::make_shared<RadioResponseInfo>();error->error=ErrType::ERR_GENERIC_FAILURE;
                RealScenario::Reply(pending,error);
                std::lock_guard<std::mutex> lock(handoff->mutex);handoff->producerDone=true;handoff->changed.notify_all();
            });
            {std::unique_lock<std::mutex> lock(handoff->mutex);
             handoff->insertedWhilePaused=handoff->changed.wait_for(lock,200ms,[&]{return handoff->producerDone;});
             handoff->release=true;handoff->changed.notify_all();}
            producer.get();return true;
        });
    }
'''+needle,1)
needle='                RealScenario::Reply({slot, event->GetOwner(), event->GetInnerEventId()}, response);';replacement='''                if(interleaveHandoff && protocol.sessionId==3) {
                    std::optional<RealScenario::Pending> first;
                    {std::lock_guard<std::mutex> lock(handoff->mutex);
                     if(slot==0)handoff->first=RealScenario::Pending{slot,event->GetOwner(),event->GetInnerEventId()};
                     else {handoff->second=RealScenario::Pending{slot,event->GetOwner(),event->GetInnerEventId()};first=handoff->first;}}
                    if(first)RealScenario::Reply(*first,response);
                } else RealScenario::Reply({slot, event->GetOwner(), event->GetInnerEventId()}, response);''';assert needle in b;b=b.replace(needle,replacement,1)
needle='    const auto done = std::chrono::steady_clock::now() + 3s;';b=b.replace(needle,'''    if(coordinate.valid()) {
        EXPECT_TRUE(coordinate.get());
        testing::Test::RecordProperty("retry3_inserted_during_handoff",handoff->insertedWhilePaused?"true":"false");
    }
'''+needle,1)
needle='TEST(ConcurrencyRegression, C1RetriesDrainWhileStopping)\n{VerifyC1FailureRetries(true);}';b=b.replace(needle,needle+'\nTEST(ConcurrencyRegression, C1RetryHandoffInterleaving)\n{VerifyC1FailureRetries(false,true);}',1);p.write_text(a+b)
# Both previous compiles finished; tests operate solely on the finished binaries.
dest=w/'ci/repo/telephony_core_service/services/multisim/test/systemtest/primary_slot/real_test.cpp';dest.write_bytes(p.read_bytes());
for n in ('phase-thread','phase-address'):
 d=w/n
 for f in ('0.log','1.log','commands.json'):
  (d/('handoff-diagnostic-'+f)).write_bytes((d/f).read_bytes())
print('Added controlled real C1 session3 handoff, Stop+retry and45s timeout tests')
