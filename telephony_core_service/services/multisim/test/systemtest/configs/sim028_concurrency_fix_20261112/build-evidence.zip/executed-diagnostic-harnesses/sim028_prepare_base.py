from pathlib import Path
import json,subprocess,hashlib
root=Path.cwd();s=root/'telephony_core_service/services/multisim/test/systemtest';ad=s/'primary_slot/lifecycle/admission';w=Path(json.load(open('/tmp/sim028-concurrency-current.json'))['work']);base=w/'increment-base';base.mkdir();names=['telephony_core_service/services/sim/include/sim_state_handle.h','telephony_core_service/services/sim/src/sim_state_handle.cpp','telephony_core_service/utils/common/src/tel_event_queue.cpp']+[str((s/x).relative_to(root)) for x in ['stubs/ffrt_runtime.h','stubs/ffrt_runtime.cpp','stubs/include/hilog/log.h','primary_slot/real_test.cpp']];rows={r['path']:r for r in json.loads((ad/'patch-manifest.json').read_text())['files']}
for name in names:
 p=base/name;p.parent.mkdir(parents=True,exist_ok=True);raw=(root/name).read_bytes();p.write_bytes(raw.replace(b'\r\n',b'\n') if name in rows else raw)
for patch in ['production-minimal.patch','test-guard.patch']:
 args=['git','apply']+['--include='+n for n in names]+[str(ad/patch)];subprocess.run(args,cwd=base,check=True)
for name in names:
 if name in rows:assert hashlib.sha256((base/name).read_bytes()).hexdigest()==rows[name]['candidate_sha256']
(w/'increment-files.json').write_text(json.dumps(names,indent=2));print('Reconstructed7 base files from persisted patches, matching hashes')
