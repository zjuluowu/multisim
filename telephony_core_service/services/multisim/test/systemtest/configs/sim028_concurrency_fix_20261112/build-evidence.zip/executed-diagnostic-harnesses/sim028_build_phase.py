import pathlib,json,subprocess,sys
w=pathlib.Path(json.load(open('/tmp/sim028-concurrency-current.json'))['work']);repo=w/'ci/repo';s=repo/'telephony_core_service/services/multisim/test/systemtest';profile=sys.argv[1];out=w/('phase-'+profile);out.mkdir(exist_ok=True);commands=[['python3','-B',str(s/'tools/host.py'),'configure','--target','sim_primary_slot_real_test','--with-real-primary','--out',str(out),'--gtest-root','/tmp/sim-host-deps/googletest-b514bdc898e2951020cbdca1304b75f5950d1f59','--openssl-root','/tmp/sim028-deps/openssl','--runtime-root','/tmp/sim028-deps/native','--sanitizer',profile],['ninja','-C',str(out/'build'),'-j','2','sim_primary_slot_real_test']];(out/'commands.json').write_text(json.dumps(commands,indent=2))
for i,c in enumerate(commands):
 with (out/f'{i}.log').open('w') as f:r=subprocess.run(c,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:sys.exit(r.returncode)
print(out)
