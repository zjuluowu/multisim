from pathlib import Path
import json
w=Path(json.load(open('/tmp/sim028-concurrency-current.json'))['work']);repo=w/'ci/repo';pending=w/'pending';pending.mkdir(exist_ok=True);s=repo/'telephony_core_service/services/multisim/test/systemtest'
# Prepare diagnostic changes separately; apply only after phase builds finish.
p=s/'stubs/include/hilog/log.h';t=p.read_text();t=t.replace('inline int HILOG_IMPL(','''namespace SimHost {
bool HasLogObserver();
void ObserveHostLog(const std::string &line);
void SetLogObserver(std::function<void(const std::string &)> observer);
}
inline int HILOG_IMPL(''');t=t.replace('#include <cstdarg>','#include <cstdarg>\n#include <functional>');t=t.replace('    if (!std::getenv("SIM_HOST_TRACE")) return 0;','    const bool trace=std::getenv("SIM_HOST_TRACE") != nullptr;\n    if (!trace && !SimHost::HasLogObserver()) return 0;');t=t.replace('    flockfile(stderr);','''    va_list observerArgs; va_copy(observerArgs,args);
    char buffer[2048];std::vsnprintf(buffer,sizeof(buffer),clean.c_str(),observerArgs);va_end(observerArgs);
    SimHost::ObserveHostLog(buffer);
    if (!trace) {va_end(args);return 0;}
    flockfile(stderr);''');(pending/'log.h').write_text(t)
p=s/'stubs/ffrt_runtime.cpp';t=p.read_text();t+='''
namespace SimHost {
namespace {
std::mutex logObserverMutex;
std::function<void(const std::string &)> logObserver;
std::atomic_bool hasLogObserver{false};
}
bool HasLogObserver() {return hasLogObserver.load();}
void SetLogObserver(std::function<void(const std::string &)> observer) {
    std::lock_guard<std::mutex> lock(logObserverMutex);
    logObserver=std::move(observer);hasLogObserver=bool(logObserver);
}
void ObserveHostLog(const std::string &line) {
    std::function<void(const std::string &)> observer;
    {std::lock_guard<std::mutex> lock(logObserverMutex);observer=logObserver;}
    if(observer)observer(line); // No registry lock across a test barrier.
}
}
''';(pending/'ffrt_runtime.cpp').write_text(t)
p=repo/'telephony_core_service/utils/common/src/tel_event_queue.cpp';t=p.read_text();needle='    SubmitToFFRT(queueId, handleTime, delayTime);';assert needle in t;t=t.replace(needle,'    TELEPHONY_LOGD("SIM028_QUEUE_HANDOFF name=%{public}s revision=%{public}d delay_us=%{public}lld",\n        name_.c_str(), queueId, static_cast<long long>(delayTime));\n'+needle);(pending/'tel_event_queue.cpp').write_text(t)
p=s/'primary_slot/real_test.cpp';t=p.read_text();i=t.index('TEST(RealSimPrimary, C1CheckFailureRestoresParametersAndExhaustsFiveRetries)');head,tail=t[:i],t[i:];needle='    EXPECT_EQ(s.core.SetPrimarySlotId(1), TELEPHONY_ERR_LOCAL_PTR_NULL);';assert tail.count(needle)==1;tail=tail.replace(needle,needle+'\n    if (std::getenv("SIM_HOST_INJECT_C1_ASSERT")) {\n        ASSERT_TRUE(false) << "INJECTED_C1_FATAL_ASSERT";\n    }');t=head+tail;t=t.replace('#include <optional>','#include <optional>\n#include "sim_state_handle.h"\n#include "hilog/log.h"')
t+='''
namespace {
struct HandoffState {
    std::mutex mutex;std::condition_variable changed;
    bool paused=false,release=false,producerStarted=false,producerDone=false,delivered=false;
};
class HandoffHandler final : public OHOS::Telephony::TelEventHandler {
public:
    explicit HandoffHandler(std::shared_ptr<HandoffState> state)
        : TelEventHandler("QueueHandoffRegression"),state_(std::move(state)) {}
    void ProcessEvent(const OHOS::AppExecFwk::InnerEvent::Pointer &event) override {
        if(event->GetInnerEventId()==3) {
            std::lock_guard<std::mutex> lock(state_->mutex);state_->delivered=true;state_->changed.notify_all();
        }
    }
private:std::shared_ptr<HandoffState> state_;
};
TEST(ConcurrencyRegression, QueueHandoffDoesNotDelayImmediateEvent)
{
    auto state=std::make_shared<HandoffState>();
    auto handler=std::make_shared<HandoffHandler>(state);
    ASSERT_TRUE(handler->SendEvent(2,45000)); // Retain real long-delay work behind the initial event.
    SimHost::SetLogObserver([state](const std::string &line) {
        if(line.find("SIM028_QUEUE_HANDOFF name=QueueHandoffRegression")==std::string::npos ||
           line.find("delay_us=4")==std::string::npos)return;
        std::unique_lock<std::mutex> lock(state->mutex);
        if(state->paused)return;
        state->paused=true;state->changed.notify_all();state->changed.wait(lock,[&]{return state->release;});
    });
    EXPECT_TRUE(handler->SendEvent(1));
    bool paused;
    {std::unique_lock<std::mutex> lock(state->mutex);paused=state->changed.wait_for(lock,3s,[&]{return state->paused;});}
    std::thread producer([handler,state] {
        {std::lock_guard<std::mutex> lock(state->mutex);state->producerStarted=true;state->changed.notify_all();}
        EXPECT_TRUE(handler->SendEvent(3));
        {std::lock_guard<std::mutex> lock(state->mutex);state->producerDone=true;state->changed.notify_all();}
    });
    bool insertedWhilePaused=false;
    {std::unique_lock<std::mutex> lock(state->mutex);
     EXPECT_TRUE(state->changed.wait_for(lock,3s,[&]{return state->producerStarted;}));
     // A bounded observation rendezvous, not a sleep or a business deadline change.
     insertedWhilePaused=state->changed.wait_for(lock,200ms,[&]{return state->producerDone;});
     state->release=true;state->changed.notify_all();}
    producer.join();SimHost::SetLogObserver({});
    bool delivered;
    {std::unique_lock<std::mutex> lock(state->mutex);delivered=state->changed.wait_for(lock,1s,[&]{return state->delivered;});}
    EXPECT_TRUE(paused);EXPECT_TRUE(delivered) << "IMMEDIATE_EVENT_STRANDED_BEHIND_STALE_45S_SNAPSHOT";
    testing::Test::RecordProperty("producer_inserted_during_handoff",insertedWhilePaused?"true":"false");
    EXPECT_TRUE(handler->StopEvents());std::weak_ptr<HandoffHandler> weak=handler;handler.reset();
    EXPECT_TRUE(weak.expired());EXPECT_TRUE(SimHost::AwaitSchedulerStopped(3s));
}
TEST(ConcurrencyRegression, CrossQueueStateSnapshotsAndSetter)
{
    auto handle=std::make_shared<OHOS::Telephony::SimStateHandle>(std::weak_ptr<OHOS::Telephony::SimStateManager>{});
    handle->SetSimState(OHOS::Telephony::SimState::SIM_STATE_UNKNOWN);
    std::promise<void> start;auto ready=start.get_future().share();std::atomic_uint reads{0};
    std::thread writer([&] {ready.wait();for(int i=0;i<20000;++i)
        handle->SetSimState(i%2?OHOS::Telephony::SimState::SIM_STATE_READY:OHOS::Telephony::SimState::SIM_STATE_LOCKED);});
    std::thread reader([&] {ready.wait();for(int i=0;i<20000;++i) {
        auto state=handle->GetSimState();EXPECT_TRUE(state==OHOS::Telephony::SimState::SIM_STATE_UNKNOWN ||
            state==OHOS::Telephony::SimState::SIM_STATE_READY || state==OHOS::Telephony::SimState::SIM_STATE_LOCKED);++reads;}});
    start.set_value();writer.join();reader.join();EXPECT_EQ(reads.load(),20000u);
    EXPECT_TRUE(handle->StopEvents());std::weak_ptr<OHOS::Telephony::SimStateHandle> weak=handle;handle.reset();
    EXPECT_TRUE(weak.expired());EXPECT_TRUE(SimHost::AwaitSchedulerStopped(3s));
}
}
''';(pending/'real_test.cpp').write_text(t);print(pending)
