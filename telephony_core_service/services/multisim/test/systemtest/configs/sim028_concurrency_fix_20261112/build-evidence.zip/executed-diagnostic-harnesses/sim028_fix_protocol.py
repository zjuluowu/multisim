import pathlib,json,subprocess,hashlib
root=pathlib.Path.cwd();w=pathlib.Path(json.load(open('/tmp/sim028-concurrency-current.json'))['work']);n='telephony_core_service/services/sim/src/radio_protocol_controller.cpp';p=w/'increment-base'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/n).read_bytes().replace(b'\r\n',b'\n'));ad=root/'telephony_core_service/services/multisim/test/systemtest/primary_slot/lifecycle/admission';
for patch in ['production-minimal.patch','test-guard.patch']:subprocess.run(['git','apply','--include='+n,str(ad/patch)],cwd=w/'increment-base',check=True)
manifest=json.loads((ad/'patch-manifest.json').read_text());row=next(r for r in manifest['files'] if r['path']==n);assert hashlib.sha256(p.read_bytes()).hexdigest()==row['candidate_sha256'];names=json.loads((w/'increment-files.json').read_text());names.append(n);(w/'increment-files.json').write_text(json.dumps(names,indent=2))
p=w/'ci/repo'/n;s=p.read_text();s=s.replace('    CleanUpCommunication();\n    std::unique_lock<ffrt::mutex> radioProtocolLock(radioProtocolMutex_);','    std::unique_lock<ffrt::mutex> radioProtocolLock(radioProtocolMutex_);\n    CleanUpCommunication();',1)
needle='        memberFunc(event);';assert s.count(needle)==1;s=s.replace(needle,'''        // Protocol predicates, sessions, phase counters and cleanup share the
        // caller's wait mutex. Active-SIM events use their separate ctx_/cv_.
        const bool protocolEvent = id == RADIO_SIM_GET_RADIO_PROTOCOL ||
            id == RADIO_SIM_CHECK_RADIO_PROTOCOL || id == RADIO_SIM_UPDATE_RADIO_PROTOCOL ||
            id == RADIO_SIM_RADIO_PROTOCOL_NOTIFY || id == RADIO_SIM_SET_RADIO_PROTOCOL_COMPLETE ||
            id == RADIO_SIM_SET_RADIO_PROTOCOL_TIMEOUT;
        std::unique_lock<ffrt::mutex> protocolLock(radioProtocolMutex_, std::defer_lock);
        if (protocolEvent) {
            protocolLock.lock();
        }
        memberFunc(event);''')
for method in ['ExecuteUpdateCommunication()','ExecuteCompleteCommunication()','UpdateRadioProtocol(std::shared_ptr<RadioProtocol> radioProtocol)']:
 needle='void RadioProtocolController::'+method+'\n{\n    std::unique_lock<ffrt::mutex> radioProtocolLock(radioProtocolMutex_);';assert needle in s;s=s.replace(needle,'// Called with radioProtocolMutex_ held by protocol dispatch or SetRadioProtocol.\nvoid RadioProtocolController::'+method+'\n{')
p.write_text(s)
# Exportv2 without rewriting the v1 patches being consumed by running CI.
p=pathlib.Path('/tmp/sim028_export_increment.py');s=p.read_text();s=s.replace("assert '    if (!hasLogObserver.load(std::memory_order_acquire)) return;' not in t;",'');s=s.replace("t=t.replace('void ObserveHostLog(const std::string &line) {','void ObserveHostLog(const std::string &line) {\\n    if (!hasLogObserver.load(std::memory_order_acquire)) return;')","t=t if '    if (!hasLogObserver.load(std::memory_order_acquire)) return;' in t else t.replace('void ObserveHostLog(const std::string &line) {','void ObserveHostLog(const std::string &line) {\\n    if (!hasLogObserver.load(std::memory_order_acquire)) return;')");s=s.replace('production-increment.patch','production-increment-v2.patch').replace('test-increment.patch','test-increment-v2.patch').replace('increment-manifest.json','increment-manifest-v2.json').replace("check=w/'increment-check'","check=w/'increment-check-v2'").replace('Production3/test5 union7','Production4/test5 union8');pathlib.Path('/tmp/sim028_export_increment_v2.py').write_text(s)
print('Protocol dispatch and waiter now share the existing protocol mutex; nested helper locks removed')
