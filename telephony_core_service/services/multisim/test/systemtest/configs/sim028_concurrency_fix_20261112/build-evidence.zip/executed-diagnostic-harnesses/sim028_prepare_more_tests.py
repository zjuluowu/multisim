import json,pathlib
w=pathlib.Path(json.load(open('/tmp/sim028-concurrency-current.json'))['work']);p=w/'ci/repo/telephony_core_service/services/multisim/test/systemtest/primary_slot/real_test.cpp';s=p.read_text();s=s.replace('TEST(RealSimPrimary, C1CheckFailureRestoresParametersAndExhaustsFiveRetries)\n{','void VerifyC1FailureRetries(bool stopDuringRetry = false)\n{',1)
pos=s.index('void VerifyC1FailureRetries');a=s[:pos];b=s[pos:];needle='    EXPECT_EQ(s.core.SetPrimarySlotId(1), TELEPHONY_ERR_LOCAL_PTR_NULL);';b=b.replace(needle,needle+'''
    if(stopDuringRetry) {
        bool pending=false;
        for(const auto &q:SimHost::GetQueueEvidence())
            pending|=q.name=="MultiSimController" && q.pending>0;
        EXPECT_TRUE(pending) << "STOP_MUST_BEGIN_WITH_ORIGINAL_RETRY_PENDING";
        EXPECT_TRUE(s.manager->Stop());EXPECT_TRUE(s.manager->IsStopped());
        testing::Test::RecordProperty("stop_started_with_queued_retry",pending?"true":"false");
    }''',1);s=a+b;needle='}\nint main(int argc, char **argv)';assert needle in s;s=s.replace(needle,'''
TEST(RealSimPrimary, C1CheckFailureRestoresParametersAndExhaustsFiveRetries)
{VerifyC1FailureRetries();}
TEST(ConcurrencyRegression, C1RetriesDrainWhileStopping)
{VerifyC1FailureRetries(true);}
}
int main(int argc, char **argv)''',1)
s+='''
namespace {
TEST(ConcurrencyRegression, C1CommunicationTimeoutThenFiveRetries)
{
    using namespace Sim028Host;
    std::map<int,std::vector<std::pair<int,RadioProtocolPhase>>> phases;
    unsigned requests=0;
    RealScenario s;
    ASSERT_TRUE(s.StartLockedCard());s.ClearObservations();s.Permit();
    {std::lock_guard<std::mutex> lock(s.mutex);
     s.parametersDb["persist.telephony.MainSlotId"]="0";
     s.parametersDb["persist.telephony.MainCard.Iccid"]="timeout-original-iccid";}
    EXPECT_CALL(*s.ril,SetPrimarySlot(testing::_,testing::_)).Times(0);
    EXPECT_CALL(*s.ril,GetRadioProtocol(testing::_,testing::_)).Times(2).WillRepeatedly([](int slot,const auto &event) {
        auto response=std::make_shared<RadioProtocol>();response->slotId=slot;response->modemId=slot;
        response->technology=slot==0?0x11:0x22;
        RealScenario::Reply({slot,event->GetOwner(),event->GetInnerEventId()},response);return 0;
    });
    s.manager->GetRadioProtocol(0);s.manager->GetRadioProtocol(1);
    const auto deadline=std::chrono::steady_clock::now()+3s;
    while(s.manager->GetRadioProtocolSlotIdByModemId(1)!=1 && std::chrono::steady_clock::now()<deadline)
        std::this_thread::yield();
    ASSERT_EQ(s.manager->GetRadioProtocolSlotIdByModemId(1),1);
    EXPECT_CALL(*s.ril,SetRadioProtocol(testing::_,testing::_,testing::_)).Times(22)
        .WillRepeatedly([&](int slot,RadioProtocol protocol,const auto &event) {
            {std::lock_guard<std::mutex> lock(s.mutex);
             ++requests;phases[protocol.sessionId].emplace_back(slot,protocol.phase);}
            std::cout<<"TIMEOUT_RETRY session="<<protocol.sessionId<<" phase="<<static_cast<int>(protocol.phase)
                <<" slot="<<slot<<" serial=NOT_CREATED_AT_ITelRilManager_MOCK_BOUNDARY\\n";
            EXPECT_EQ(protocol.slotId,slot);EXPECT_EQ(protocol.modemId,slot);
            if(protocol.sessionId==1) {EXPECT_EQ(protocol.phase,RadioProtocolPhase::RADIO_PROTOCOL_PHASE_CHECK);return 0;}
            if(protocol.phase==RadioProtocolPhase::RADIO_PROTOCOL_PHASE_CHECK) {
                auto error=std::make_shared<RadioResponseInfo>();error->error=ErrType::ERR_GENERIC_FAILURE;
                RealScenario::Reply({slot,event->GetOwner(),event->GetInnerEventId()},error);
            } else {
                EXPECT_EQ(protocol.phase,RadioProtocolPhase::RADIO_PROTOCOL_PHASE_COMPLETE);
                EXPECT_EQ(protocol.status,RadioProtocolStatus::RADIO_PROTOCOL_STATUS_FAIL);
                RealScenario::Reply({slot,event->GetOwner(),event->GetInnerEventId()},std::make_shared<RadioProtocol>(protocol));
            }
            return 0;
        });
    auto start=std::chrono::steady_clock::now();
    EXPECT_EQ(s.core.SetPrimarySlotId(1),TELEPHONY_ERR_LOCAL_PTR_NULL);
    EXPECT_GE(std::chrono::steady_clock::now()-start,44s);
    EXPECT_TRUE(s.manager->Stop());EXPECT_TRUE(s.manager->IsStopped());
    std::lock_guard<std::mutex> lock(s.mutex);
    EXPECT_EQ(requests,22u);EXPECT_EQ(phases.size(),6u);EXPECT_EQ(phases.count(2),0u);
    for(const auto &[session,sequence]:phases) {
        if(session==1)EXPECT_THAT(sequence,testing::ElementsAre(
            std::make_pair(0,RadioProtocolPhase::RADIO_PROTOCOL_PHASE_CHECK),
            std::make_pair(1,RadioProtocolPhase::RADIO_PROTOCOL_PHASE_CHECK)));
        else EXPECT_THAT(sequence,testing::ElementsAre(
            std::make_pair(0,RadioProtocolPhase::RADIO_PROTOCOL_PHASE_CHECK),
            std::make_pair(1,RadioProtocolPhase::RADIO_PROTOCOL_PHASE_CHECK),
            std::make_pair(0,RadioProtocolPhase::RADIO_PROTOCOL_PHASE_COMPLETE),
            std::make_pair(1,RadioProtocolPhase::RADIO_PROTOCOL_PHASE_COMPLETE)));
    }
    EXPECT_EQ(s.parametersDb["persist.telephony.MainSlotId"],"0");
    EXPECT_EQ(s.parametersDb["persist.telephony.MainCard.Iccid"],"timeout-original-iccid");
    s.ExpectNotifications(false,6,false);
    testing::Test::RecordProperty("business_assertions_before_cleanup",testing::Test::HasFailure()?"FAIL":"PASS");
    testing::Test::RecordProperty("timeout_seconds",45);
}
}
''';(w/'pending/real_test_more.cpp').write_text(s);print('Prepared retry/Stop and real45s timeout tests, not applied to active build')
