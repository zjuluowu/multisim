from pathlib import Path
import tempfile,json,hashlib,subprocess,importlib.util,zipfile,io
root=Path.cwd();s=root/'telephony_core_service/services/multisim/test/systemtest';w=Path(tempfile.mkdtemp(prefix='sim028-concurrency-'));Path('/tmp/sim028-concurrency-current.json').write_text(json.dumps({'work':str(w)}))
names=[x.decode() for x in subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','-z']).split(b'\0') if x];inputs={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in names if (root/n).is_file()};(w/'original-inputs.json').write_text(json.dumps(inputs,indent=2));(w/'git-status.txt').write_text(subprocess.check_output(['git','status','--short'],text=True));v=json.loads((s/'configs/sim028_ci_admission_20261112/validation.json').read_text());
for archive,profile,prefix in [('final-artifacts.zip','thread','tsan'),('incremental-failed.zip','address','asan')]:
 with zipfile.ZipFile(s/'configs/sim028_ci_admission_20261112'/archive) as z:
  with zipfile.ZipFile(io.BytesIO(z.read(profile+'/logs.zip'))) as zz:
   for n in zz.namelist():
    if n.endswith('.log') and ('WARNING: ThreadSanitizer' in zz.read(n).decode(errors='replace') or 'ERROR: AddressSanitizer' in zz.read(n).decode(errors='replace')):(w/(prefix+'-historical.log')).write_bytes(zz.read(n))
for profile,row in v['final_candidate_run'].items():
 binary=Path(row['run']).parents[0]/'build/sim_primary_slot_real_test'
 assert binary.is_file() and hashlib.sha256(binary.read_bytes()).hexdigest()==row['binary_sha256']['sim_primary_slot_real_test'];row['binary']=str(binary)
(w/'baseline-binaries.json').write_text(json.dumps(v['final_candidate_run'],indent=2));(w/'ci').mkdir();spec=importlib.util.spec_from_file_location('ci',s/'tools/ci_sim028.py');ci=importlib.util.module_from_spec(spec);spec.loader.exec_module(ci);repo=ci.prepare(root,w/'ci');print(w);print(repo)
