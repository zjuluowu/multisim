import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
import xml.etree.ElementTree as ET
repo=Path.cwd();core=repo/'telephony_core_service';system=core/'services/multisim/test/systemtest';out=Path('/tmp/sim-directory-mutation');out.mkdir(exist_ok=True)
source=core/'services/sim/src/sim_state_handle.cpp';original=source.read_bytes();text=source.read_text();needle='case ICC_CONTENT_READY:\n            externalState_ = SimState::SIM_STATE_READY;';assert text.count(needle)==1
mutant=out/'sim_state_handle_mutant.cpp';mutant.write_text(text.replace(needle,needle.replace('SIM_STATE_READY;','SIM_STATE_LOCKED;')))
shutil.copytree('/tmp/sim-directory-host-before/build',out/'build',dirs_exist_ok=True,copy_function=shutil.copy2)
config=json.loads(Path('/tmp/sim-directory-host-before/host.json').read_text());config['sim_guard_state_source']=str(mutant);args=' '.join(k+'='+json.dumps(v) for k,v in config.items());results=[]
def run(argv,label,timeout=900):
 start=time.monotonic()
 with (out/(label+'.log')).open('w') as f:
  p=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,timeout=timeout,env={**os.environ,'LLVM_PROFILE_FILE':str(out/(label+'.profraw'))})
 results.append({'argv':argv,'exit_code':p.returncode,'seconds':time.monotonic()-start,'log':label+'.log'});return p.returncode
assert run(['gn','gen',str(out/'build'),'--root='+str(system),'--args='+args],'gn')==0
assert run(['ninja','-C',str(out/'build'),'-j','3','sim_guard_legacy'],'build')==0
bad=run([str(out/'build/sim_guard_legacy'),'--gtest_filter=*LIFE_001','--gtest_output=xml:'+str(out/'mutant.xml')],'mutant-run',60)
normal=run(['/tmp/sim-directory-host-before/build/sim_guard_legacy','--gtest_filter=*-*DEFECT_*','--gtest_output=xml:'+str(out/'restored.xml')],'restored-run',60)
a=ET.parse(out/'mutant.xml').getroot();b=ET.parse(out/'restored.xml').getroot();protected=hashlib.sha256(source.read_bytes()).hexdigest()==hashlib.sha256(original).hexdigest();assert bad==1 and a.attrib['tests']=='1' and a.attrib['failures']=='1';assert normal==0 and b.attrib['tests']=='17' and b.attrib['failures']=='0' and protected
(out/'result.json').write_text(json.dumps({'status':'DETECTED','mutant_tests':1,'mutant_expected_failures':1,'restored_tests':17,'restored_pass':17,'production_unchanged':protected,'production_sha256':hashlib.sha256(original).hexdigest(),'mutant_sha256':hashlib.sha256(mutant.read_bytes()).hexdigest(),'commands':results},indent=2)+'\n')
print('DETECTED 1/1; restored 17/17; production unchanged')
