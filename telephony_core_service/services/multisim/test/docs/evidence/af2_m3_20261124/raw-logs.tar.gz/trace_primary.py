import lldb

def trace(frame, bp_location, internal_dict):
    line = frame.GetLineEntry()
    print(f'TRACE {frame.GetFunctionName()} {line.GetFileSpec().GetFilename()}:{line.GetLine()}')
    values = frame.GetVariables(True, False, False, True)
    if line.GetFileSpec().GetFilename() == 'multi_sim_controller.cpp' and line.GetLine() == 1571:
        value = frame.FindVariable('iccId')
        if value.IsValid() and value.GetError().Success():
            print(value)
    names = {'slot', 'slotId', 'isUserSet', 'request', 'step', 'target', 'facts', 'key', 'operation',
             'subscription', 'primarySimId_', 'legacyResult', 'waiter', 'expected', 'binding', 'selection',
             'lastPrimary', 'lastData', 'phase', 'domain', 'plan', 'session', 'simState', 'iccId'}
    for value in values:
        if value.GetName() in names and value.IsInScope():
            print(str(value)[:1800])
    return False
