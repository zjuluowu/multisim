import lldb

def trace(frame, bp_location, internal_dict):
    location = frame.GetLineEntry()
    print(f'TRACE {bp_location.GetBreakpoint().GetID()} {frame.GetFunctionName()} '
          f'{location.GetFileSpec().GetFilename()}:{location.GetLine()}')
    variables = frame.GetVariables(True, False, False, True)
    for index in range(variables.GetSize()):
        value = variables.GetValueAtIndex(index)
        name = value.GetName()
        if name in ('session', 'observation', 'application', 'generation', 'call', 'ticket', 'input',
                    'plan', 'account', 'binding', 'planned', 'evidence', 'subscription', 'view', 'slot',
                    'result', 'rewriteLabel'):
            if name == 'iccid':
                if value.GetType().IsReferenceType():
                    value = value.Dereference()
                value = value.GetNonSyntheticValue()
                data = value.GetChildMemberWithName('_M_dataplus').GetChildMemberWithName('_M_p')
                if data.IsValid():
                    error = lldb.SBError()
                    text = frame.GetThread().GetProcess().ReadCStringFromMemory(data.GetValueAsUnsigned(), 64, error)
                    if error.Success():
                        print(f'iccid = {text!r}')
                        continue
            print(str(value)[:2200])
    return False
