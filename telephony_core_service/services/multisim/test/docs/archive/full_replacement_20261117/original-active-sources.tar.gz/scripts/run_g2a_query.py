#!/usr/bin/env python3
"""Compare a host-only G2a reference with the unmodified upstream Core query."""

import sys as _sys
from pathlib import Path as _Path
_TEST_ROOT = next(p for p in _Path(__file__).resolve().parents if (p / "scripts/_paths.py").is_file())
_sys.path.insert(0, str(_TEST_ROOT / "scripts"))
from _paths import TEST as _TEST, CORE as _CORE, REPO as _REPO, locate, guard_asset
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import signal
import subprocess
import time
import xml.etree.ElementTree as ET

from build_clock import await_build_timestamps

SYSTEM = (_TEST / 'framework/host')
CORE = _CORE
SCENARIOS = [
    ("single", "1", None),
    ("dual", "2", None),
    ("zero", "0", None),
    ("negative_atoi", "-2", None),
    ("malformed_atoi", "invalid", None),
    ("vendor_override", "2", "5"),
    ("vendor_result_propagation", "2", "-31"),
]
SOURCES = [
    "services/multisim/test/framework/host/g2a_reference/core_service_sim.cpp",
    "services/multisim/test/framework/host/g2a_reference/legacy_sim_query_binding.cpp",
    "services/multisim/infrastructure/compatibility/api/real_sim_count_query.cpp",
    "services/sim/src/sim_manager.cpp",
    "services/telephony_ext_wrapper/src/telephony_ext_wrapper.cpp",
]
REQUIRED_EXECUTIONS = [
    ("CoreServiceSim", "GetRealSimCount", "services/multisim/test/framework/host/g2a_reference/core_service_sim.cpp"),
    ("CoreServiceSim", "AttachReadOnlyQueries", "services/multisim/test/framework/host/g2a_reference/core_service_sim.cpp"),
    ("LegacySimQueryBinding", "ReadLegacyRealSimCount", "services/multisim/test/framework/host/g2a_reference/legacy_sim_query_binding.cpp"),
    ("RealSimCountQuery", "Read", "services/multisim/infrastructure/compatibility/api/real_sim_count_query.cpp"),
    ("SimManager", "GetRealSimCount", "services/sim/src/sim_manager.cpp"),
    ("TelephonyExtWrapper", "GetRealSimCountExt", "services/telephony_ext_wrapper/src/telephony_ext_wrapper.cpp"),
]

VALIDATION_INPUTS = [
    "BUILD.gn", "test/BUILD.gn", "test/core_service_test.gni",
    "test/unittest/raw_parcel_core_service_gtest/BUILD.gn", "services/multisim/test/framework/host/BUILD.gn",
    "services/multisim/test/framework/host/gn/BUILDCONFIG.gn", "services/multisim/test/framework/host/gn/BUILD.gn",
    "services/multisim/test/framework/host/g2a_reference/core_service_sim.h", "services/multisim/test/framework/host/g2a_reference/legacy_sim_query_binding.h",
    "services/multisim/infrastructure/compatibility/api/real_sim_count_query.h",
    "interfaces/innerkits/include/i_sim_manager.h", "interfaces/innerkits/include/i_tel_ril_manager.h",
    "interfaces/innerkits/include/telephony_types.h", "services/multisim/test/framework/host/configs/dependency_lock.json",
    "services/multisim/test/scripts/run_g2a_query.py", "services/multisim/test/scripts/build_clock.py",
    "services/multisim/test/cases/architecture/test_g2a_source_tables.py", "services/multisim/BUILD.gn",
    "services/multisim/test/framework/host/stubs/mock_tel_ril_manager.h", "services/multisim/test/framework/host/stubs/g2a_vendor_boundary.cpp",
    "services/multisim/test/cases/host/support/g2a_query_probe.h", "services/multisim/test/cases/host/support/g2a_query_probe.cpp",
    "services/multisim/test/cases/host/g2a_query_test.cpp",
]


def gn_tokens(text):
    # Literal source-table audit only, not a GN evaluator. Keep strings intact and
    # discard comments so a commented-out source cannot count as a compiled input.
    return [token for token in re.findall(r'"(?:\\.|[^"\\])*"|#[^\n]*|\+=|-=|\w+|\S', text)
            if not token.startswith("#")]


def target_body(tokens, target):
    starts = [i + 5 for i in range(len(tokens) - 4)
              if tokens[i:i + 5] == [target[0], "(", '"' + target[1] + '"', ")", "{"]]
    if len(starts) != 1:
        raise RuntimeError("Missing or duplicate G2a target: " + target[1])
    start = starts[0]
    depth = 1
    for end in range(start, len(tokens)):
        depth += (tokens[end] == "{") - (tokens[end] == "}")
        if depth == 0:
            return tokens[start:end]
    raise RuntimeError("Unclosed G2a target: " + target[1])


def literal_lists(tokens, field):
    """Read unconditional literal lists; conditional additions cannot supply G2a."""
    depth = 0
    values = []
    for i, token in enumerate(tokens[:-2]):
        depth += (token == "{") - (token == "}")
        if depth or token != field or tokens[i + 1] not in {"=", "+=", "-="}:
            continue
        if tokens[i + 2] != "[":
            raise RuntimeError("Non-literal G2a list: " + field)
        end = tokens.index("]", i + 3)
        content = tokens[i + 3:end]
        if any(item != "," and not item.startswith('"') for item in content):
            raise RuntimeError("Non-literal G2a list entry: " + field)
        items = [item[1:-1] for item in content if item != ","]
        if tokens[i + 1] == "=":
            values = items
        elif tokens[i + 1] == "+=":
            values.extend(items)
        else:
            values = [value for value in values if value not in items]
    return values


def verify_source_tables(read_text=None):
    read_text = read_text or (lambda name: (CORE / name).read_text())
    production_tables = ["BUILD.gn", "test/BUILD.gn", "test/core_service_test.gni",
                         "test/unittest/raw_parcel_core_service_gtest/BUILD.gn"]
    for name in production_tables:
        tokens = gn_tokens(read_text(name))
        if any("multisim" in token or "legacy_sim_query_binding" in token for token in tokens):
            raise RuntimeError("Refactor attachment leaked into upstream build: " + name)
    name = "services/multisim/test/framework/host/BUILD.gn"
    tokens = gn_tokens(read_text(name))
    body = target_body(tokens, ("source_set", "g2a_readonly_production_host"))
    sources = literal_lists(body, "sources")
    for source in SOURCES[:3]:
        expected = ("$test_root/" + source.split("services/multisim/test/", 1)[1]
                    if "/test/" in source else "$production_root/" + source)
        if sources.count(expected) != 1:
            raise RuntimeError("Missing or duplicate reference input: " + source)
    if len(sources) != 3:
        raise RuntimeError("Unexpected reference source")
    launcher = target_body(tokens, ("source_set", "g2a_query_launcher"))
    if "$test_root/framework/host/g2a_reference" not in literal_lists(launcher, "include_dirs"):
        raise RuntimeError("Missing reference header boundary")
    leaf = target_body(gn_tokens(read_text("services/multisim/BUILD.gn")), ("source_set", "readonly_query"))
    if (leaf[:3] != ["testonly", "=", "true"] or
            literal_lists(leaf, "sources") != ["infrastructure/compatibility/api/real_sim_count_query.cpp", "infrastructure/compatibility/api/real_sim_count_query.h"] or
            literal_lists(leaf, "public") != ["infrastructure/compatibility/api/real_sim_count_query.h"] or
            any(field in leaf for field in ["deps", "public_deps", "public_configs"])):
        raise RuntimeError("G2a leaf must remain isolated and testonly")
    return {"tables": production_tables + [name], "production_attachment_absent": True, "reference_inputs_exact": True,
            "narrow_query_include_boundary": True, "isolated_testonly_leaf": True,
            "product_admission": "NOT_PROVEN_BY_SOURCE_TABLE_CHECK"}


def digest_tree(root):
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if path.is_file():
            digest.update(str(path.relative_to(root)).encode() + b"\0" + path.read_bytes() + b"\0")
    return digest.hexdigest()


def is_method(function, owner, method):
    # These non-template methods use the Itanium ABI. Lengths and the closing E
    # prevent Read matching ReadLegacyRealSimCount, or Init matching OnInit.
    return str(len(owner)) + owner + str(len(method)) + method + "E" in function["name"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gtest-root", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--libxml2-include", default=os.environ.get("SIM_LIBXML2_INCLUDE", "/usr/include/libxml2"),
                        help="libxml2 headers directory; defaults to SIM_LIBXML2_INCLUDE or the standard Linux location")
    args = parser.parse_args()
    output = Path(args.output).resolve()
    if output == CORE or CORE in output.parents:
        raise SystemExit("G2a build/run output must be outside repository sources")
    output.mkdir(parents=True, exist_ok=True)
    result = {
        "schema_version": 1,
        "case_id": "SIM-G2A-READ-001",
        "status": "BLOCKED",
        "executed": False,
        "scope": "test_reference_Core_attachment_to_upstream_SimManager",
        "manager_on_init_executed": False,
        "core_init_executed": False,
        "card_presence": "not_observed_or_required_for_this_query",
        "device_runtime": "not_connected",
        "original_capacity_suite": "not_run_or_counted_here",
        "full_sim_initialization": "not_claimed",
        "production_sources": [],
        "production_attachment_present": False,
        "scenario_counting": "Seven parameter/vendor scenarios, each run against reference and upstream executables",
        "commands": [],
        "scenarios": [],
        "counts": {"PASS": 0, "FAIL": 0, "BLOCKED": 1},
        "environment": {"os": platform.platform(), "cpu": platform.machine()},
        "limits": ["Core attachment is a test reference only; upstream production has no attachment. No CoreService::Init, Manager::OnInit, IPC/SA/permission or device validation",
                   "LTO intentionally closes only the selected production query",
                   "RIL is a strict platform Mock; vendor override is an explicit ABI boundary"],
    }

    # Clear only this runner's known execution artifacts before any fallible preparation.
    # A failed or interrupted retry must not leave an earlier PASS XML/JSON as current evidence.
    for name, _, _ in SCENARIOS:
        for extension in [".xml", ".profraw"]:
            (output / ("g2a-" + name + extension)).unlink(missing_ok=True)
            (output / ("upstream-" + name + extension)).unlink(missing_ok=True)
    for artifact in ["g2a-query.profdata", "coverage-export.log"]:
        (output / artifact).unlink(missing_ok=True)
    (output / "g2a-query-result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")

    def command(argv, name, timeout=120, environment=None, runtime=False):
        start = time.monotonic()
        process = subprocess.Popen(argv, cwd=output, env=environment, text=True,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
        if runtime:
            result["executed"] = True
        try:
            stdout, stderr = process.communicate(timeout=timeout)
            code = process.returncode
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            stdout, stderr = process.communicate()
            code = 124
        text = stdout + stderr
        (output / (name + ".log")).write_text(text)
        result["commands"].append({"argv": argv, "exit_code": code,
                                   "elapsed_seconds": time.monotonic() - start, "log": name + ".log"})
        if code:
            raise RuntimeError(name + " failed; see " + str(output / (name + ".log")))
        return stdout

    try:
        result["head_sha"] = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=CORE, text=True).strip()
        result["dirty"] = bool(subprocess.check_output(["git", "status", "--porcelain"], cwd=CORE, text=True))
        lock = json.loads(((_TEST / 'framework/host/configs/dependency_lock.json')).read_text())
        gtest = Path(args.gtest_root).resolve()
        if digest_tree(gtest) != lock["googletest"]["tree_sha256"]:
            raise RuntimeError("GoogleTest tree differs from pinned dependency")
        for header in lock["platform_headers"]:
            if hashlib.sha256((SYSTEM / header["path"]).read_bytes()).hexdigest() != header["sha256"]:
                raise RuntimeError("Pinned platform header changed: " + header["path"])
        result["googletest_commit"] = lock["googletest"]["commit"]
        result["production_sources"] = [{"path": path, "sha256": hashlib.sha256((CORE / path).read_bytes()).hexdigest()}
                                        for path in SOURCES]
        result["integration_source_tables"] = verify_source_tables()
        result["validation_inputs"] = [{"path": path, "sha256": hashlib.sha256((CORE / path).read_bytes()).hexdigest()}
                                       for path in VALIDATION_INPUTS]
        result["toolchain"] = {}
        for tool in ["gn", "ninja", "clang++", "ld.gold", "llvm-profdata-18", "llvm-cov-18"]:
            result["toolchain"][tool] = command([tool, "--version"], "version-" + tool).splitlines()[0]
        command(["python3", str((_TEST / 'scripts/generate_ril_mock.py')), "--check"], "ril-interface-check")
        result["build_clock"] = await_build_timestamps(SYSTEM)
        gn_args = "production_root=" + json.dumps(str(CORE)) + " gtest_root=" + json.dumps(str(gtest))
        gn_args += " libxml2_include_dir=" + json.dumps(str(Path(args.libxml2_include).resolve()))
        result["blocking_stage"] = "gn_generation"
        command(["gn", "gen", str(output), "--root=" + str(SYSTEM), "--args=" + gn_args], "gn-gen")
        result["blocking_stage"] = "query_product_link"
        command(["ninja", "-C", str(output), "-j", "3", "sim_g2a_query_test", "sim_upstream_query_test"], "ninja-build", timeout=300)
        command(["clang++", "-std=c++17", "-fPIC", "-shared",
                 str((_TEST / 'framework/host/stubs/g2a_vendor_boundary.cpp')),
                 "-o", str(output / "libtelephony_ext_service.z.so")], "vendor-abi-boundary-build")
        result["blocking_stage"] = "runtime"
        profiles = []
        for name, parameter, vendor in SCENARIOS:
            xml = output / ("g2a-" + name + ".xml")
            profile = output / ("g2a-" + name + ".profraw")
            xml.unlink(missing_ok=True)
            profile.unlink(missing_ok=True)
            environment = os.environ.copy()
            environment.pop("SIM_G2A_VENDOR_RESULT", None)
            environment.pop("SIM_HOST_NEGATIVE_CONTROL", None)
            environment["SIM_G2A_SLOT_PARAMETER"] = parameter
            environment["LD_LIBRARY_PATH"] = str(output)
            environment["LLVM_PROFILE_FILE"] = str(profile)
            if vendor is not None:
                environment["SIM_G2A_VENDOR_RESULT"] = vendor
            command([str(output / "sim_g2a_query_test"),
                     "--gtest_filter=G2aReadOnlyQuery.OriginalManagerAttachment",
                     "--gtest_output=xml:" + str(xml)], "run-" + name, timeout=15, environment=environment, runtime=True)
            tree = ET.parse(xml).getroot()
            cases = tree.findall(".//testcase")
            if len(cases) != 1 or tree.findall(".//failure") or tree.findall(".//skipped"):
                raise RuntimeError("Unexpected GoogleTest scenario result: " + name)
            properties = {x.attrib["name"]: x.attrib["value"] for x in tree.findall(".//property")}
            result["scenarios"].append({"name": name, "status": "PASS", "xml": xml.name,
                                        "slot_parameter": parameter, "vendor_result": vendor,
                                        "properties": properties})
            upstream_xml = output / ("upstream-" + name + ".xml")
            upstream_xml.unlink(missing_ok=True)
            environment["LLVM_PROFILE_FILE"] = str(output / ("upstream-" + name + ".profraw"))
            command([str(output / "sim_upstream_query_test"), "--gtest_output=xml:" + str(upstream_xml)],
                    "upstream-run-" + name, timeout=15, environment=environment, runtime=True)
            upstream_tree = ET.parse(upstream_xml).getroot()
            if len(upstream_tree.findall(".//testcase")) != 1 or upstream_tree.findall(".//failure") or upstream_tree.findall(".//skipped"):
                raise RuntimeError("Upstream query scenario failed: " + name)
            result["scenarios"][-1]["upstream_xml"] = upstream_xml.name
            profiles.append(str(profile))
        result["blocking_stage"] = "production_execution_audit"
        profdata = output / "g2a-query.profdata"
        command(["llvm-profdata-18", "merge", "-sparse", *profiles, "-o", str(profdata)], "coverage-merge")
        coverage_text = command(["llvm-cov-18", "export", str(output / "sim_g2a_query_test"),
                                 "-instr-profile=" + str(profdata)], "coverage-export")
        coverage = json.loads(coverage_text)
        functions = [function for section in coverage["data"] for function in section["functions"]]
        audits = []
        for owner, symbol, source in REQUIRED_EXECUTIONS:
            expected_source = (CORE / source).resolve()
            matches = [function for function in functions
                       if is_method(function, owner, symbol) and
                       any(Path(filename).resolve() == expected_source for filename in function["filenames"])]
            if not any(function["count"] > 0 for function in matches):
                raise RuntimeError("No actual production execution evidence: " + owner + "::" + symbol)
            audits.extend({"name": item["name"], "executions": item["count"], "filenames": item["filenames"]}
                          for item in matches)
        initializers = []
        for owner, method in [("SimManager", "OnInit"), ("CoreService", "Init")]:
            boot = [item for item in functions if is_method(item, owner, method)]
            count = sum(item["count"] for item in boot)
            initializers.append({"function": owner + "::" + method, "executions": count,
                                 "present_in_coverage": bool(boot)})
            if count:
                raise RuntimeError("Selected query unexpectedly executed " + owner + "::" + method)
        link_map = output / "sim_g2a_query_test.map"
        if not link_map.exists() or not link_map.stat().st_size:
            raise RuntimeError("Missing query product link map")
        result["production_execution_audit"] = {"functions": audits, "link_map": link_map.name,
                                                 "initializers": initializers,
                                                 "purpose": "actual production participation, not an exact count Oracle",
                                                 "lto_scope": "selected query only; uncalled platform paths eliminated"}
        result["status"] = "PASS"
        result["counts"] = {"PASS": len(result["scenarios"]), "FAIL": 0, "BLOCKED": 0}
        result["blocking_stage"] = None
        result["binary_sha256"] = hashlib.sha256((output / "sim_g2a_query_test").read_bytes()).hexdigest()
    except Exception as error:
        result["diagnostic"] = str(error)
        if result["executed"]:
            result["status"] = "FAIL"
            result["counts"] = {"PASS": len(result["scenarios"]), "FAIL": 1, "BLOCKED": 0}
    finally:
        (output / "g2a-query-result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "executed": result["executed"], "counts": result["counts"],
                      "result": str(output / "g2a-query-result.json")}, ensure_ascii=False))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
