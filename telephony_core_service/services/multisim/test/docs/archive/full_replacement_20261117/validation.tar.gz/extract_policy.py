import ast,json,hashlib,shutil
from pathlib import Path
T=Path('/mnt/e/github/multisim/telephony_core_service/services/multisim/test')
rows=json.loads((T/'docs/Full_Replacement_Migration.json').read_text())
def move(a,b):
 src=T/a;dst=T/b;dst.parent.mkdir(parents=True,exist_ok=True);d=src.read_bytes();src.rename(dst);rows['files'].append({'old':a,'new':b,'action':'moved','before_sha256':hashlib.sha256(d).hexdigest()})
move('cases/primary_slot/oracle/primary_oracle.py','cases/primary_expectations.py')
move('cases/primary_slot/oracle/test_primary_oracle.py','cases/infrastructure/test_primary_expectations.py')
move('cases/primary_slot/scenarios/primary_slot.json','cases/data/primary_inputs.json')
move('cases/primary_slot/legacy_contract/golden.json','cases/data/primary_golden.json')
move('cases/primary_slot/lifecycle/admission/ci_policy.json','cases/data/admission_policy.json')
p=T/'cases/infrastructure/test_primary_expectations.py';s=p.read_text().replace('import primary_oracle','import primary_expectations as primary_oracle').replace('from primary_oracle import','from primary_expectations import').replace("sys.path.insert(0, str(Path(__file__).resolve().parent))","sys.path.insert(0, str(_TEST / 'cases'))").replace("'cases/primary_slot/scenarios/primary_slot.json'","'cases/data/primary_inputs.json'")
# Existing test uses a module alias named oracle; keep that local name.
s=s.replace('import primary_expectations as primary_oracle as oracle','import primary_expectations as oracle')
# Add the cases import root explicitly, independent of prior relocation aliases.
s='import sys\nfrom pathlib import Path\nsys.path.insert(0, str(Path(__file__).resolve().parents[1]))\n'+s;p.write_text(s)
s=(T/'scripts/run_legacy_primary_contract.py').read_text();tree=ast.parse(s);func=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='classify');body=ast.get_source_segment(s,func).replace(r'real_scenario\.h',r'(?:real_scenario|primary_environment)\.h');(T/'scripts/primary_results.py').write_text('"""Fail-closed business/lifecycle classification; no build or execution code."""\nimport re\n'+body+'\n')
s=(T/'scripts/ci_sim028.py').read_text();tree=ast.parse(s);names=['parse_discovery','read_case','evaluate'];parts=[ast.get_source_segment(s,n) for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
header='''"""Historical admission policy checks retained as pure regression functions."""
import json,re,xml.etree.ElementTree as ET
from pathlib import Path
from _paths import TEST
POLICY = json.loads((TEST/'cases/data/admission_policy.json').read_text())
_LOCATION_ORIGINS = {'telephony_core_service/services/multisim/test/'+r['new']: 'telephony_core_service/services/multisim/test/'+r['old'] for r in json.loads((TEST/'docs/Test_Architecture_Migration.json').read_text())['files'] if Path(r['old']).suffix in ('.cpp','.h','.hpp')}
def normalize(message):
    message = re.sub(r'^[^\\n]*?telephony_core_service/', 'telephony_core_service/', message, flags=re.M)
    return re.sub(r'^([^:\\n]+)(?=:\\d+\\b)', lambda match: _LOCATION_ORIGINS.get(match.group(1), match.group(1)), message, flags=re.M)
'''
(T/'scripts/admission_policy.py').write_text(header+'\n\n'.join(parts)+'\n')
p=T/'cases/infrastructure/test_ci_sim028.py';p.write_text(p.read_text().replace('import ci_sim028 as ci','import admission_policy as ci'))
p=T/'cases/infrastructure/test_legacy_primary_contract.py';p.write_text(p.read_text().replace('from run_legacy_primary_contract import classify','from primary_results import classify'))
(T/'docs/Full_Replacement_Migration.json').write_text(json.dumps(rows,indent=2)+'\n')
