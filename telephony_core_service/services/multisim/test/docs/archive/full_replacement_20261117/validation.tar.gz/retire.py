from pathlib import Path
import json,hashlib,subprocess,tarfile,re
T=Path('/mnt/e/github/multisim/telephony_core_service/services/multisim/test');R=T.parents[3];p=T/'docs/Full_Replacement_Migration.json';m=json.loads(p.read_text())
with tarfile.open(T/m['archive']) as a:original={x.name:a.extractfile(x).read() for x in a if x.isfile()}
retire=set()
for directory in ['cases/compatibility','cases/primary_slot','framework/compatibility']:
 for f in (T/directory).rglob('*'):
  if f.is_file() and f.relative_to(T).as_posix() in original:retire.add(f.relative_to(T).as_posix())
for name in ['event_adapter','event_transport','external_services','native_pointer','ril_adapter']:retire.add('cases/infrastructure/'+name+'_test.cpp')
old_scripts=['host.py','debug_host.sh','build_host.sh','run_host_tests.sh','run.py','run_sim_guard.py','run_pin_memory_contract.py','run_g2a_query.py','run_primary_contract.py','run_legacy_primary_contract.py','run_primary_real.py','run_primary_slot.py','ci_sim028.py','run_diagnostics.py','trace_graph.py','summarize_graph.py','review_graph.py','reproduce_initialization.py','audit_initialization.py','audit_primary_contract.py','check_stop_contract.py','validate_patch.py','compare_layout_results.py','check_relocation.py','build_clock.py']
retire.update('scripts/'+s for s in old_scripts)
for name in sorted(retire):
 f=T/name
 if not f.is_file():continue
 if f.read_bytes()!=original[name]:raise RuntimeError('Do not retire modified input: '+name)
 m['files'].append({'old':name,'new':None,'action':'retired','before_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'replacement':'Unified test.py/GTest fixture or immutable original-active-sources archive; case mapping in Full_Replacement_Coverage.json'})
 f.unlink()
# Remove only newly empty directories; untracked files are never removed.
for root in ['cases/compatibility','cases/primary_slot','cases/host','framework/compatibility']:
 for directory in sorted((T/root).rglob('*'),key=lambda q:len(q.parts),reverse=True):
  if directory.is_dir():
   try:directory.rmdir()
   except OSError:pass
 try:(T/root).rmdir()
 except OSError:pass
s=(T/'framework/host/BUILD.gn').read_text()
for name in ['sim_guard_legacy','sim_guard_pin_memory','platform_adapter_test','primary_slot_contract']:
 pattern=re.search(r'(?:executable|source_set)\("'+name+r'"\)\s*\{',s)
 if not pattern:continue
 start=pattern.start();i=pattern.end();depth=1
 while depth:
  depth+=(s[i]=='{')-(s[i]=='}');i+=1
 s=s[:start]+s[i:].lstrip('\n')
s=s.replace('":primary_slot_contract", ','')
(T/'framework/host/BUILD.gn').write_text(s)
# Record explicit rewrites separately from immutable historical evolution hashes.
for name in ['framework/host/BUILD.gn','scripts/check_test_integrity.py','scripts/test.py','scripts/build_replacement.py','scripts/run_gtest.py','scripts/update_case_sources.py']:
 m['files'].append({'old':name,'new':name,'action':'rewritten','before_sha256':hashlib.sha256(original[name]).hexdigest()})
p.write_text(json.dumps(m,indent=2)+'\n')
e=T/'docs/Full_Replacement_Evolution.json';x=json.loads(e.read_text());x['completion']={'baseline':m['baseline'],'migration':'docs/Full_Replacement_Migration.json','coverage':'docs/Full_Replacement_Coverage.json','reason':'User-authorized complete replacement; preserve prior bootstrap digest record as historical evidence, not as a freeze of active framework implementation.'};e.write_text(json.dumps(x,indent=2)+'\n')
print('retired',len(retire),'original files; archive retained exact bytes')
