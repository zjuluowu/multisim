from pathlib import Path
import hashlib,json,subprocess,tarfile,io
T=Path('/mnt/e/github/multisim/telephony_core_service/services/multisim/test');R=T.parents[3]
base='807d73fbefdd6d7652a88187ae06211cc98e6de4'
archive=T/'docs/archive/full_replacement_20261117';archive.mkdir(parents=True,exist_ok=True)
raw=subprocess.check_output(['git','archive',base,str(T.relative_to(R))],cwd=R)
with tarfile.open(fileobj=io.BytesIO(raw)) as source,tarfile.open(archive/'original-active-sources.tar.gz','w:gz') as output:
 for member in source:
  if member.isfile() and '/docs/archive/' not in member.name:
   data=source.extractfile(member).read(); member.name=member.name.split('services/multisim/test/',1)[1];output.addfile(member,io.BytesIO(data))
rows=[]
def move(old,new):
 src=T/old;dst=T/new
 assert src.is_file() and not dst.exists(),(old,new)
 dst.parent.mkdir(parents=True,exist_ok=True);data=src.read_bytes();src.rename(dst)
 rows.append({'old':old,'new':new,'action':'moved','before_sha256':hashlib.sha256(data).hexdigest()})
for name in ['capacity','bootstrap']:
 move('cases/host/'+name+'_test.cpp','cases/capacity/'+name+'_test.cpp')
for name in ['g2a_query','g2a_upstream']:
 move('cases/host/'+name+'_test.cpp','cases/query/'+name+'_test.cpp')
for f in sorted((T/'cases/host/support').glob('*')):
 if f.is_file():move(str(f.relative_to(T)),'framework/host/probes/'+f.name)
move('cases/primary_slot/entry_test.cpp','cases/primary_entry/primary_entry_test.cpp')
move('cases/primary_slot/real_test.cpp','cases/primary/primary_test.cpp')
move('cases/primary_slot/lifecycle/lifetime_test.cpp','cases/primary/lifecycle_test.cpp')
move('cases/primary_slot/lifecycle/shutdown_contract_test.cpp','cases/primary/shutdown_test.cpp')
helpers=['real_scenario.h','real_runtime.cpp','security_boundary.cpp','security_boundary.h','unscripted_sim_manager.h','initialization_trace.h']
for s in helpers:move('cases/primary_slot/'+s,'framework/host/primary/'+s)
for folder in ['include','runtime_include','provider/include','lifecycle']:
 for f in sorted((T/'cases/primary_slot'/folder).glob('*.h')):move(str(f.relative_to(T)),'framework/host/primary/'+folder+'/'+f.name)
# Former infrastructure copies are the same tests, now compiled only once.
for f in ['event_adapter','event_transport','external_services','native_pointer','ril_adapter']:
 move('cases/'+f+'_test.cpp','cases/platform/'+f+'_test.cpp')
for f in ['lifecycle','pin_and_response','pin_memory']:
 move('cases/'+f+'_test.cpp','cases/protocol/'+f+'_test.cpp')
move('framework/host/ril_device.h','framework/common/ril_device.h')
move('framework/host/ril_fault_controls.h','framework/common/ril_fault_controls.h')
move('framework/compatibility/contracts/primary_slot.h','framework/common/primary_observation.h')
p=T/'framework/common/primary_observation.h';s=p.read_text();a=s.index('// Test port only.');b=s.index('inline std::string Json',a);p.write_text(s[:a]+s[b:])
# Remove an adapter layer: the environment calls its real Core directly.
p=T/'framework/host/primary/real_scenario.h';s=p.read_text().replace('#include "adapters/legacy/legacy_primary_adapter.h"','#include "common/primary_observation.h"')
s=s.replace('SimGuard::Primary::LegacyAdapter core{observation};','CoreServiceSim core;\n    int SetPrimarySlotId(int slot)\n    {\n        observation.Add("api_input", {{"slot", std::to_string(slot)}});\n        const int result = core.SetPrimarySlotId(slot);\n        std::string symbol = result == TELEPHONY_ERR_SUCCESS ? "TELEPHONY_ERR_SUCCESS" :\n            result == TELEPHONY_ERR_LOCAL_PTR_NULL ? "TELEPHONY_ERR_LOCAL_PTR_NULL" :\n            result == TELEPHONY_ERR_NO_SIM_CARD ? "TELEPHONY_ERR_NO_SIM_CARD" : "UNMAPPED:" + std::to_string(result);\n        observation.Add("api_return", {{"result", std::to_string(result)}, {"symbol", symbol}});\n        return result;\n    }')
p.write_text(s)
for directory in ['cases/primary','framework/host/primary']:
 for p in (T/directory).rglob('*'):
  if p.suffix not in ['.cpp','.h']:continue
  s=p.read_text().replace('RealScenario','PrimaryEnvironment').replace('.core.SetPrimarySlotId(','.SetPrimarySlotId(')
  if directory=='cases/primary':s=s.replace('#include "real_scenario.h"','#include "sim_primary_test.h"')
  s=s.replace('../../../framework/host/stubs/include/hisysevent.h','../../stubs/include/hisysevent.h')
  p.write_text(s)
move('framework/host/primary/real_scenario.h','framework/host/primary/primary_environment.h')
for p in (T/'framework/host/primary').rglob('*'):
 if p.suffix in ['.h','.cpp']:p.write_text(p.read_text().replace('real_scenario.h','primary_environment.h'))
(T/'framework/sim_primary_test.h').write_text('// SPDX-License-Identifier: Apache-2.0\n#pragma once\n#include "host/primary/primary_environment.h"\n')
# Each executable gets the common process/profile entry point.
for folder in ['cases/capacity','cases/query','cases/primary_entry','cases/primary']:
 for p in (T/folder).glob('*.cpp'):
  s=p.read_text()
  if '\nint main(' in s:s=s[:s.index('\nint main(')]+'\n'
  p.write_text(s)
# Physical path references in the Host build follow the move list.
p=T/'framework/host/BUILD.gn';s=p.read_text()
for row in rows:s=s.replace('$test_root/'+row['old'],'$test_root/'+row['new'])
s=s.replace('$test_root/cases/host/support','$test_root/framework/host/probes')
for old,new in [('cases/primary_slot/runtime_include','framework/host/primary/runtime_include'),('cases/primary_slot/provider/include','framework/host/primary/provider/include'),('cases/primary_slot/include','framework/host/primary/include'),('cases/primary_slot','framework/host/primary')]:s=s.replace('$test_root/'+old,'$test_root/'+new)
s=s.replace('"$test_root/cases/compatibility",\n    "$test_root/framework/compatibility",','"$test_root/framework",')
# Temporary original binaries remain until comparison, all use isolated defaults too.
for label,var in [('sim_component_test','sim_capacity_case_sources'),('sim_bootstrap_characterization','sim_bootstrap_case_sources'),('sim_primary_slot_entry_test','sim_primary_entry_case_sources'),('sim_g2a_query_test','sim_reference_case_sources'),('sim_upstream_query_test','sim_upstream_case_sources')]:
 start=s.index('executable("'+label+'")');a=s.index('sources = [',start);b=s.index(']',a)+1
 current=s[a:b];extras=[]
 if label=='sim_primary_slot_entry_test':extras=['"$test_root/framework/host/primary/security_boundary.cpp"']
 s=s[:a]+'sources = '+var+' + [ "$test_root/framework/common/main.cpp"'+(' , '+', '.join(extras) if extras else '')+' ]'+s[b:]
start=s.index('executable("sim_primary_slot_real_test")');a=s.index('sources = [',start);b=s.index(']',a)+1
s=s[:a]+'sources = sim_primary_case_sources + [ "$test_root/framework/common/main.cpp", "$test_root/framework/host/primary/real_runtime.cpp", "$test_root/framework/host/primary/security_boundary.cpp" ]'+s[b:]
s=s.replace('sources = sim_case_sources + [','sources = sim_case_sources + sim_protocol_case_sources + sim_platform_case_sources + [')
# Access to the primary public fixture, not case headers.
start=s.index('executable("sim_primary_slot_real_test")');a=s.index('include_dirs = [',start);s=s[:a]+s[a:].replace('include_dirs = [','include_dirs = [ "$test_root/framework",',1)
# All programs link GoogleMock with their own common entry point.
# Explicit absolute fallback protects arbitrary direct invocations as well as wrappers.
s=s.replace('"-fprofile-instr-generate"','"-fprofile-instr-generate=" + get_path_info(root_build_dir, "abspath") + "/profiles/direct-%p.profraw"')
p.write_text(s)
# New common pure transport types have no Host dependency.
for p in [T/'framework/host/sim_test.cpp',T/'framework/sim_advanced_test.h']:
 s=p.read_text().replace('"host/ril_device.h"','"common/ril_device.h"').replace('"host/ril_fault_controls.h"','"common/ril_fault_controls.h"').replace('"ril_device.h"','"common/ril_device.h"').replace('"ril_fault_controls.h"','"common/ril_fault_controls.h"');p.write_text(s)
# Declared provenance, not a test registration table.
(T/'docs/Full_Replacement_Migration.json').write_text(json.dumps({'schema_version':1,'baseline':base,'archive':'docs/archive/full_replacement_20261117/original-active-sources.tar.gz','archive_sha256':hashlib.sha256((archive/'original-active-sources.tar.gz').read_bytes()).hexdigest(),'files':rows},indent=2)+'\n')
print('moved',len(rows),'files')
