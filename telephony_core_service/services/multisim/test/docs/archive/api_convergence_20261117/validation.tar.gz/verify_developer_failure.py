from pathlib import Path
import subprocess,json,hashlib,os
repo=Path('/mnt/e/github/multisim');test=repo/'telephony_core_service/services/multisim/test';work=Path('/tmp/sim-converge-ge5ovs3w');case=test/'cases/pin_failure_isolation_test.cpp';binary=Path('/tmp/sim-final-host/build/sim_test_host')
original=case.read_bytes();source_sha=hashlib.sha256(original).hexdigest();binary_sha=hashlib.sha256(binary.read_bytes()).hexdigest();rows=[]
def execute(name):
 cmd=['python3','-B',str(test/'scripts/test.py'),'run','--filter','SimTest.WrongUsimPinDoesNotBlockSimPeer','--out','/tmp/sim-final-host','--output',str(work/name)]
 with (work/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,LLVM_PROFILE_FILE=str(work/(name+'-%p.profraw'))))
 rows.append({'name':name,'command':cmd,'exit_code':r.returncode});return r.returncode
try:
 text=original.decode();needle='ExpectCardState(b, State::Locked); // Peer before unlock.';assert text.count(needle)==1
 case.write_text(text.replace(needle,'ExpectCardState(b, State::Ready); // Intentionally false expectation.'))
 code=execute('developer-expected-failure')
finally:case.write_bytes(original)
recovery=execute('developer-recovery')
source_ok=hashlib.sha256(case.read_bytes()).hexdigest()==source_sha;binary_ok=hashlib.sha256(binary.read_bytes()).hexdigest()==binary_sha
frozen=json.loads((work/'developer-framework-before.json').read_text());changed=[name for name,digest in frozen.items() if hashlib.sha256((test/name).read_bytes()).hexdigest()!=digest]
reports=list((work/'developer-expected-failure').glob('sim-*/result.json'));assert len(reports)==1
raw=json.loads(reports[0].read_text());assert len(raw['cases'])==1
row=raw['cases'][0];actual_failure=row['status']=='FAIL' and row['exit_code']==1 and 'actual.state' in ''.join(row['details']['failures'])
result={'status':'PASS' if code==1 and recovery==0 and source_ok and binary_ok and not changed and actual_failure else 'FAIL','commands':rows,'intentional_expectation_failure_observed':actual_failure,'source_restored':source_ok,'normal_binary_restored':binary_ok,'framework_scripts_changed':changed,'human_modified_case_files':1,'manual_build_metadata_edits':0,'public_headers':['sim_test.h'],'cpp_lines':len(original.splitlines()),'protected_profile_sha256':hashlib.sha256((repo/'default.profraw').read_bytes()).hexdigest()}
(work/'developer-acceptance.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));raise SystemExit(0 if result['status']=='PASS' else 1)
